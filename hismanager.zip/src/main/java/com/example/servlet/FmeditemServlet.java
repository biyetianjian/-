package com.example.servlet;

import com.example.dao.DepartmentDao;
import com.example.dao.ExpenseclassDao;
import com.example.dao.FmeditemDao;
import com.example.model.Department;
import com.example.model.Expenseclass;
import com.example.model.Fmeditem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "FmeditemServlet", value = "/FmeditemServlet")
public class FmeditemServlet extends HttpServlet {


    FmeditemDao fmeditemDao = new FmeditemDao();
    ExpenseclassDao expenseclassDao = new ExpenseclassDao();
    DepartmentDao departmentDao = new DepartmentDao();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }
    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     *            添加方法的参数名：addmethod
     *            修改：    updatemethod
     *            删除：    deletemethod
     *            根据主键查询科室信息: findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addFmeditem(request,response);
        }else if("updatemethod".equals(methodname)){
            updateFmeditem(request,response);
            //修改操作
        }else if("cancelmethod".equals(methodname)){
            //删除操作
            cancelFmeditemById(request,response);
        }else if("findid".equals(methodname)) {
            //根据主键查询数据表信息
            findfmeditemById(request, response);
        }else if("addinput".equals(methodname)){
            addinput(request,response);
        }else{
            //执行查询所有记录
            findAll(request,response);
        }
    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Department> departments = departmentDao.findAll();

        //2.存储部门信息
        request.setAttribute("departmentObjs",departments);
        List<Expenseclass> expenseclasss = expenseclassDao.findAll();
        request.setAttribute("expenseclassObjs",expenseclasss);
        //List<DepartmentLevel> departmentLevels = departmentLevelDao.findAll();
        //2.存储部门信息
        //request.setAttribute("departmentLevelObjs",departmentLevels);
        request.getRequestDispatcher("/system/addfmeditem.jsp").forward(request,response);
    }
    /**
     * 功能：前端控制器--添加科室操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addFmeditem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String fmeditemCode = request.getParameter("itemcode");
        String fmeditemName = request.getParameter("itemname");
        int fmedexpclassId = Integer.parseInt(request.getParameter("expclassid"));
        int deptId = Integer.parseInt(request.getParameter("deptid"));
        String fmedmnemonicCode = request.getParameter("mnemoniccode");
        String fmedcreationDate = request.getParameter("creationdate");
        String fmedlastupdateDate = request.getParameter("lastupdatedate");
        int fmedrecordType = Integer.parseInt(request.getParameter("recordtype"));
        int fmeddelMark = Integer.parseInt(request.getParameter("delmark"));
        String fmeddelDate = request.getParameter("deldate");


        Fmeditem fmeditem = new Fmeditem();


        fmeditem.setItemcode(fmeditemCode);
        fmeditem.setItemname(fmeditemName);
        fmeditem.setExpclassid(fmedexpclassId);
        fmeditem.setDeptid(deptId);
        fmeditem.setMnemoniccode(fmedmnemonicCode);
        fmeditem.setCreationdate(fmedcreationDate);
        fmeditem.setLastupdatedate(fmedlastupdateDate);
        fmeditem.setRecordtype(fmedrecordType);
        fmeditem.setDelmark(fmeddelMark);
        fmeditem.setDeldate(fmeddelDate);

        fmeditemDao.addFmeditem(fmeditem);
        findAll(request,response);
    }
    protected void updateFmeditem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String fmeditemCode = request.getParameter("itempcode");
        String fmeditemName = request.getParameter("itemname");
        int fmedexpclassId = Integer.parseInt(request.getParameter("expclassid"));
        int deptId = Integer.parseInt(request.getParameter("deptid"));
        String fmedmnemonicCode = request.getParameter("mnemoniccode");
        String fmedcreationDate = request.getParameter("creationdate");
        String fmedlastupdateDate = request.getParameter("lastupdatedate");
        int fmedrecordType = Integer.parseInt(request.getParameter("recordtype"));
        int fmeddelMark = Integer.parseInt(request.getParameter("delmark"));
        String fmeddelDate = request.getParameter("deldate");

        Fmeditem fmeditem = new Fmeditem();

        fmeditem.setId(id);
        fmeditem.setItemcode(fmeditemCode);
        fmeditem.setItemname(fmeditemName);
        fmeditem.setExpclassid(fmedexpclassId);
        fmeditem.setDeptid(deptId);
        fmeditem.setMnemoniccode(fmedmnemonicCode);
        fmeditem.setCreationdate(fmedcreationDate);
        fmeditem.setLastupdatedate(fmedlastupdateDate);
        fmeditem.setRecordtype(fmedrecordType);
        fmeditem.setDelmark(fmeddelMark);
        fmeditem.setDeldate(fmeddelDate);



        fmeditemDao.updateFmeditem(fmeditem);
        findAll(request,response);
    }

    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Fmeditem> fmeditems = fmeditemDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("fmeditemObjs",fmeditems);
        request.getRequestDispatcher("/system/displayfmeditem.jsp").forward(request,response);
    }
    protected void findfmeditemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        int fmedid = Integer.parseInt(request.getParameter("fmedid"));
        Fmeditem fmeditem= fmeditemDao.findFmeditemByID(fmedid);
        //2.跳转到显示页面中
        request.setAttribute("fmedobj",fmeditem);
        request.getRequestDispatcher("/system/updatefmeditem.jsp").forward(request,response);
    }
    protected void deleteFmeditemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int fmedid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        fmeditemDao.deleteFmeditem(fmedid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }
    protected void cancelFmeditemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int fmedid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        fmeditemDao.cancelFmeditem(fmedid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }

}

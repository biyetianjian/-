package com.example.servlet;

import com.example.dao.ExpenseclassDao;
import com.example.model.Expenseclass;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ExpenseclassServlet", value = "/ExpenseclassServlet")
public class ExpenseclassServlet extends HttpServlet {


    ExpenseclassDao expenseclassDao = new ExpenseclassDao();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     * 添加方法的参数名：addmethod
     * 修改：    updatemethod
     * 删除：    deletemethod
     * 根据主键查询科室信息: findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            //添加操作
            addExpenseclass(request, response);
        } else if ("updatemethod".equals(methodname)) {
            updateExpenseclass(request,response);
            //修改操作
        } else if ("deletemethod".equals(methodname)) {
            //删除操作
            deleteExpenseclassById(request,response);
        } else if ("findid".equals(methodname)) {
            //根据主键查询数据表信息
            findexpenseclassById(request,response);


        } else {
            //执行查询所有记录
            findAll(request, response);
        }
    }

    /**
     * 功能：前端控制器--添加科室操作
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addExpenseclass(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String expenseclassCode = request.getParameter("expcode");
        String expenseclassName = request.getParameter("expname");


        Expenseclass expenseclass = new Expenseclass();


        expenseclass.setExpcode(expenseclassCode);
        expenseclass.setExpname(expenseclassName);


        expenseclassDao.addExpenseclass(expenseclass);

        findAll(request,response);
    }
    protected void updateExpenseclass(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String expenseclassCode = request.getParameter("expcode");
        String expenseclassName = request.getParameter("expname");


        Expenseclass expenseclass = new Expenseclass();

        expenseclass.setId(id);
        expenseclass.setExpcode(expenseclassCode);
        expenseclass.setExpname(expenseclassName);


        expenseclassDao.updateExpenseclass(expenseclass);

        findAll(request,response);
    }

    /**
     * 功能：查询科室信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Expenseclass> expenseclasss = expenseclassDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("expenseclassObjs", expenseclasss);
        request.getRequestDispatcher("/system/displayexpenseclass.jsp").forward(request, response);
    }

    protected void findexpenseclassById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int expenid = Integer.parseInt(request.getParameter("expenid"));
        Expenseclass expenseclass= expenseclassDao.findExpenseclassByID(expenid);
        request.setAttribute("expenobj", expenseclass);
        request.getRequestDispatcher("/system/updateexpenseclass.jsp").forward(request,response);
    }
    protected void deleteExpenseclassById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int expenid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        expenseclassDao.deleteExpenseclass(expenid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }

}


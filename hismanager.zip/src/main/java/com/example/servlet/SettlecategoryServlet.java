package com.example.servlet;

import com.example.dao.SettlecategoryDao;
import com.example.model.Settlecategory;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

    @WebServlet(name = "SettlecategoryServlet", value = "/SettlecategoryServlet")
    public class SettlecategoryServlet extends HttpServlet {

        SettlecategoryDao settlecategoryDao = new SettlecategoryDao();

        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            execute(request,response);
        }

        @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            execute(request,response);
        }

        protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            String methodname =  request.getParameter("method");
            if("addmethod".equals(methodname)){

                addSettlecategory(request,response);
            }else if("updatemethod".equals(methodname)){
                updatedSettlecategory(request, response);

            }else if("deletemethod".equals(methodname)){
                deleteSettlecategoryId(request, response);

            }else if("findid".equals(methodname)){
                findSettlecategoryId(request, response);

            }else if ("cancelmethod".equals(methodname)) {

                cancelmethod(request, response);

            }else{

                findAll(request,response);
            }
        }

        protected void addSettlecategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            String registCode = request.getParameter("registcode");
            String registName = request.getParameter("registname");
            int sequenceNo = Integer.parseInt(request.getParameter("sequenceno"));
            int delMark = Integer.parseInt(request.getParameter("delmark"));
            String delDate = request.getParameter("deldate");

            Settlecategory settlecategory = new Settlecategory();

            settlecategory.setRegistcode(registCode);
            settlecategory.setRegistname(registName);
            settlecategory.setSequenceno(sequenceNo);
            settlecategory.setDelmark(delMark);
            settlecategory.setDeldate(delDate);

            settlecategoryDao.addSettlecategory(settlecategory);

            findAll(request,response);

        }

        protected void updatedSettlecategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int id = Integer.parseInt(request.getParameter("id"));
            String registCode = request.getParameter("registcode");
            String registName = request.getParameter("registname");
            int sequenceNo = Integer.parseInt(request.getParameter("sequenceno"));
            int delMark = Integer.parseInt(request.getParameter("delmark"));
            String delDate = request.getParameter("deldate");

            Settlecategory settlecategory = new Settlecategory();

            settlecategory.setId(id);
            settlecategory.setRegistcode(registCode);
            settlecategory.setRegistname(registName);
            settlecategory.setSequenceno(sequenceNo);
            settlecategory.setDelmark(delMark);
            settlecategory.setDeldate(delDate);

            settlecategoryDao.updateSettlecategory(settlecategory);

            findAll(request,response);

        }

        protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            List<Settlecategory> settlecategorys = settlecategoryDao.findAll();

            request.setAttribute("settlecategoryObjs",settlecategorys);

            request.getRequestDispatcher("/system/displaysettlecategory.jsp").forward(request,response);

        }

        protected void findSettlecategoryId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int sssid = Integer.parseInt(request.getParameter("sssid"));

            Settlecategory settlecategory = settlecategoryDao.findSettlecategoryID(sssid);

            request.setAttribute("sssobj", settlecategory);

            request.getRequestDispatcher("/system/updatesettlecategory.jsp").forward(request, response);

        }
        protected void deleteSettlecategoryId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int sssid = Integer.parseInt(request.getParameter("did"));

            settlecategoryDao.deleteSettlecategory(sssid);

            findAll(request, response);
        }
        protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int sssid = Integer.parseInt(request.getParameter("did"));

            settlecategoryDao.cancelSettlecategory(sssid);

            findAll (request,response);
        }
    }



package com.example.servlet;

import com.example.dao.DrugsDao;
import com.example.model.Drugs;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DrugsServlet", value = "/DrugsServlet")
public class DrugsServlet extends HttpServlet {

    //2.创建数据库访问层对象
    DrugsDao drugsDao = new DrugsDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }


    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     *            添加方法的参数名：addmethod
     *            修改：    updatemethod
     *            删除：    deletemethod
     *            根据主键查询科室信息: findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addDrugs(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updateDrugs(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除操作
            deleteDrugsById(request,response);
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findDrugsById(request,response);

        }else{
            //执行查询所有记录
            findAll(request,response);
        }
    }
    /**
     * 功能：前端控制器--添加科室操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addDrugs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String drugsCode = request.getParameter("drugscode");
        String drugsName = request.getParameter("drugsname");
        String drugsFormat = request.getParameter("drugsformat");
        String drugsUnit = request.getParameter("drugsunit");
        String manuFacturer = request.getParameter("manufacturer");
        int drugsPrice = Integer.parseInt(request.getParameter("drugsprice"));
        int drugsTypeid = Integer.parseInt(request.getParameter("drugstypeid"));
        String mnemonicCode = request.getParameter("mnemoniccode");
        String creationDate = request.getParameter("creationdate");

        //创建Deparmtn对象
        Drugs drugs = new Drugs();
        drugs.setDrugscode(drugsCode);
        drugs.setDrugsname(drugsName);
        drugs.setDrugsformat(drugsFormat);
        drugs.setDrugsunit(drugsUnit);
        drugs.setManufacturer(manuFacturer);
        drugs.setDrugsprice(drugsPrice);
        drugs.setDrugstypeid(drugsTypeid);
        drugs.setMnemoniccode(mnemonicCode);
        drugs.setCreationdate(creationDate);


        //3.调用数据库访问层中的添加方法
        drugsDao.addDrugs(drugs);

        //4.跳转到成功提示页面
        findAll(request,response);

    }
    protected void updateDrugs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (deptcode ,deptname  , deptcategoryid ,depttype)
        int id = Integer.parseInt(request.getParameter("id"));
        String drugsCode = request.getParameter("drugscode");
        String drugsName = request.getParameter("drugsname");
        String drugsFormat = request.getParameter("drugsformat");
        String drugsUnit = request.getParameter("drugsunit");
        String manuFacturer = request.getParameter("manufacturer");
        int drugsPrice = Integer.parseInt(request.getParameter("drugsprice"));
        int drugsTypeid = Integer.parseInt(request.getParameter("drugstypeid"));
        String mnemonicCode = request.getParameter("mnemoniccode");
        String creationDate = request.getParameter("creationdate");

        //创建Deparmtn对象
        Drugs drugs = new Drugs();
        drugs.setId(id);
        drugs.setDrugscode(drugsCode);
        drugs.setDrugsname(drugsName);
        drugs.setDrugsformat(drugsFormat);
        drugs.setDrugsunit(drugsUnit);
        drugs.setManufacturer(manuFacturer);
        drugs.setDrugsprice(drugsPrice);
        drugs.setDrugstypeid(drugsTypeid);
        drugs.setMnemoniccode(mnemonicCode);
        drugs.setCreationdate(creationDate);

        //3.调用数据库访问层中的修改方法
        drugsDao.updateDrugs(drugs);

        //4.跳转到显示页面
        findAll(request,response);

    }

    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Drugs> drugss = drugsDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("drugsObjs",drugss);
        request.getRequestDispatcher("/system/displaydrugs.jsp").forward(request,response);
    }

    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findDrugsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int drugsid = Integer.parseInt(request.getParameter("drugsid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Drugs department= drugsDao.findDrugsByID(drugsid);

        //3.跳转到修改显示页面
        request.setAttribute("drugsobj",department);
        request.getRequestDispatcher("/system/updatedrugs.jsp").forward(request,response);
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteDrugsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int drugsid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        drugsDao.deleteDrugs(drugsid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }
}


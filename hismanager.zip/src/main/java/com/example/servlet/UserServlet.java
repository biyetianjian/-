package com.example.servlet;

import com.example.dao.DepartmentDao;
import com.example.dao.RegistlevelDao;
import com.example.dao.UserDao;
import com.example.model.Department;
import com.example.model.Registlevel;
import com.example.model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "UserServlet", value = "/UserServlet")
public class UserServlet extends HttpServlet {

    UserDao userDao = new UserDao();
    DepartmentDao departmentDao = new DepartmentDao();
    RegistlevelDao registlevelDao = new RegistlevelDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {

            addUser(request, response);
        } else if ("updatemethod".equals(methodname)) {

            updateUser(request, response);

        } else if ("deletemethod".equals(methodname)) {

            deleteUserId(request, response);

        } else if ("findid".equals(methodname)) {

            findUserId(request, response);

        }else if ("cancelmethod".equals(methodname)) {

            cancelmethod(request, response);

        }else if ("addinput".equals(methodname)){

            addinput(request,response);

        } else {

            findall(request, response);
        }
    }

    protected void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userName = request.getParameter("username");
        String passWord = request.getParameter("password");
        String realName = request.getParameter("realname");
        int useType = Integer.parseInt(request.getParameter("usetype"));
        String docTitleid = request.getParameter("doctitleid");
        int deptId = Integer.parseInt(request.getParameter("deptid"));
        int registleId = Integer.parseInt(request.getParameter("registleid"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        User user = new User();

        user.setUsername(userName);
        user.setPassword(passWord);
        user.setRealname(realName);
        user.setUsetype(useType);
        user.setDoctitleid(docTitleid);
        user.setRegistleid(deptId);
        user.setRegistleid(registleId);
        user.setDelmark(delMark);

        userDao.addUser(user);

        findall(request,response);

    }

    protected void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String userName = request.getParameter("username");
        String passWord = request.getParameter("password");
        String realName = request.getParameter("realname");
        int useType = Integer.parseInt(request.getParameter("usetype"));
        String docTitleid = request.getParameter("doctitleid");
        int deptId = Integer.parseInt(request.getParameter("deptid"));
        int registleId = Integer.parseInt(request.getParameter("registleid"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        User user = new User();
        user.setId(id);
        user.setUsername(userName);
        user.setPassword(passWord);
        user.setRealname(realName);
        user.setUsetype(useType);
        user.setDoctitleid(docTitleid);
        user.setRegistleid(deptId);
        user.setRegistleid(registleId);
        user.setDelmark(delMark);

        userDao.updateUser(user);

        findall(request, response);

    }

    protected void findall(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<User> users = userDao.findAll();

        request.setAttribute("userObjs", users);

        request.getRequestDispatcher("/system/displayuser.jsp").forward(request, response);

    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Department> departments = departmentDao.findAll();

        request.setAttribute("departmentObjs", departments);

        List<Registlevel> registlevels = registlevelDao.findall();

        request.setAttribute("registlevelObjs", registlevels);

        request.getRequestDispatcher("/system/adduser.jsp").forward(request, response);

    }

    protected void findUserId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("sssid"));

        User user = userDao.findUserID(sssid);

        request.setAttribute("sssobj", user);

        request.getRequestDispatcher("/system/updateuser.jsp").forward(request, response);

    }

    protected void deleteUserId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("did"));

        userDao.deleteUser(sssid);

        findall(request, response);
    }

    protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("did"));

        userDao.cancelUser(sssid);

        findall(request,response);
    }
}
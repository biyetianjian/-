package com.example.servlet;

import com.example.dao.DisecategoryDao;
import com.example.model.Disecategory;
import com.example.model.Register;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DisecategoryServlet", value = "/DisecategoryServlet")
public class DisecategoryServlet extends HttpServlet {


    DisecategoryDao disecategoryDao = new DisecategoryDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }
    /**
     *  执行添加，修改，删除，查询
     *         添加：addmethod
     *         修改：updatemethod
     *         删除：deletemethod
     *         查询：findRegitserByIdmethod
     *         默认：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)) {
            //添加
            addDisecategory(request, response);
        }else if("updatemethod".equals(methodname)){
            //修改
            updateDisecategory(request,response);


        }else if("deletemethod".equals(methodname)){
            //删除
            delDisecategoryID(request,response);

        }else if ("findid".equals(methodname)){
            //查询id
            findid(request,response);
        }else if ("cancelmethod".equals(methodname)) {
            //作废id
            cancelDisecategoryID(request,response);
        }else {
                //默认
                findAll(request,response);
            }
    }




    /**
     * 添加
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addDisecategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取信息(dicacode,dicaname,sequenceno,dicatype,delmark,deldate)
        String disecategoryCode = request.getParameter("dicacode");
        String disecategoryName = request.getParameter("dicaname");
        Integer disecategoryNo = Integer.parseInt(request.getParameter("sequenceno"));
        Integer disecategoryType = Integer.parseInt(request.getParameter("dicatype"));
        Integer disecategoryMark = Integer.parseInt(request.getParameter("delmark"));
        String disecategoryDate = request.getParameter("deldate");


        //创建对象
        Disecategory disecategory = new Disecategory();
        disecategory.setDicacode(disecategoryCode);
        disecategory.setDicaname(disecategoryName);
        disecategory.setSequenceno(disecategoryNo);
        disecategory.setDicatype(disecategoryType);
        disecategory.setDelmark(disecategoryMark);
        disecategory.setDeldate(disecategoryDate);

        //调用添加方法
        disecategoryDao.addDisecategory(disecategory);

        //跳到显示页面
        findAll(request,response);
    }

    //修改
    protected void updateDisecategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int disecategoryId = Integer.parseInt(request.getParameter("id"));
        String disecategoryCode = request.getParameter("dicacode");
        String disecategoryName = request.getParameter("dicaname");
        int disecategoryNo = Integer.parseInt(request.getParameter("sequenceno"));
        int disecategoryType = Integer.parseInt(request.getParameter("dicatype"));
        int disecategoryMark = Integer.parseInt(request.getParameter("delmark"));
        String disecategoryDate = request.getParameter("deldate");



        //创建对象
        Disecategory disecategory = new Disecategory();
        disecategory.setId(disecategoryId);
        disecategory.setDicacode(disecategoryCode);
        disecategory.setDicaname(disecategoryName);
        disecategory.setSequenceno(disecategoryNo);
        disecategory.setDicatype(disecategoryType);
        disecategory.setDelmark(disecategoryMark);
        disecategory.setDeldate(disecategoryDate);

        //调用添加方法
        disecategoryDao.updateDisecategory(disecategory);

        //跳到显示页面
        findAll(request,response);
    }

    //删除
    protected void delDisecategoryID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dcid = Integer.parseInt(request.getParameter("dcid"));

        disecategoryDao.deleteDisecategory(dcid);

        findAll(request,response);
    }
    //查询id

    protected void findid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dcid = Integer.parseInt(request.getParameter("dcid"));

        Disecategory disecategory = disecategoryDao.findDiesecategoryID(dcid);

        request.setAttribute("dcobj",disecategory);
        request.getRequestDispatcher("/system/updatedisecategory.jsp").forward(request,response);
    }

    //查询
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        //调用查询方法
        List<Disecategory> disecategories = disecategoryDao.findAll();

        //跳到显示页面
        request.setAttribute("disecategoryObjs",disecategories);
        request.getRequestDispatcher("/system/displaydisecategory.jsp").forward(request,response);
    }

    //作废
    protected void cancelDisecategoryID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dcid = Integer.parseInt(request.getParameter("dcid"));
        disecategoryDao.cancelDisecategory(dcid);
        findAll(request,response);
    }
}


package com.example.servlet;

import com.example.dao.*;
import com.example.model.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CheckapplyServlet", value = "/CheckapplyServlet")
public class CheckapplyServlet extends HttpServlet {

    //2.创建数据库访问层对象
    CheckapplyDao checkapplyDao = new CheckapplyDao();
    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();
    RegisterDao registerDao = new RegisterDao();
    FmeditemDao fmeditemDao = new FmeditemDao();
    UserDao userDao = new UserDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     *            添加方法的参数名：addmethod
     *            修改：    updatemethod
     *            删除：    deletemethod
     *            根据主键查询科室信息: findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addCheckapply(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updateCheckapply(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除操作
            deleteCheckapplyById(request,response);
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findCheckapplyById(request,response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        }else{
            //执行查询所有记录
            findAll(request,response);
        }
    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        request.setAttribute("medicalrecordObjs",medicalrecords);
        List<Register> registers = registerDao.findALL();
        request.setAttribute("registerObjs",registers);
        List<Fmeditem> fmeditems = fmeditemDao.findAll();
        request.setAttribute("fmeditemObjs",fmeditems);
        List<User> users = userDao.findAll();
        request.setAttribute("userObjs",users);

        //2.存储部门信息

        //List<DepartmentLevel> departmentLevels = departmentLevelDao.findAll();
        //2.存储部门信息
        //request.setAttribute("departmentLevelObjs",departmentLevels);
        request.getRequestDispatcher("/system/addcheckapply.jsp").forward(request,response);
    }
    /**
     * 功能：前端控制器--添加科室操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addCheckapply(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (medicalid ,registlid  ,itemid ,name ,objective ,position,isurgent ,num)

        int itemid = Integer.parseInt(request.getParameter("itemid"));
        String name = request.getParameter("name");
        String objective = request.getParameter("objective");
        String position = request.getParameter("position");
        int isurgent = Integer.parseInt(request.getParameter("isurgent"));
        int num = Integer.parseInt(request.getParameter("num"));


        //创建对象
        Checkapply checkapply = new Checkapply();

        checkapply.setItemid(itemid);
        checkapply.setName(name);
        checkapply.setObjective(objective);
        checkapply.setPosition(position);
        checkapply.setIsurgent(isurgent);
        checkapply.setNum(num);


        //3.调用数据库访问层中的添加方法
        checkapplyDao.addCheckapply(checkapply);

        //4.跳转到成功提示页面
        findAll(request,response);

    }
    protected void updateCheckapply(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        int itemid = Integer.parseInt(request.getParameter("itemid"));
        String name = request.getParameter("name");
        String objective = request.getParameter("objective");
        String position = request.getParameter("position");
        int isurgent = Integer.parseInt(request.getParameter("isurgent"));
        int num = Integer.parseInt(request.getParameter("num"));
        String creationtime = request.getParameter("creationtime");
        int checkoperid = Integer.parseInt(request.getParameter("checkoperid"));
        int resultoperid = Integer.parseInt(request.getParameter("resultoperid"));
        int state = Integer.parseInt(request.getParameter("state"));

        Checkapply checkapply = new Checkapply();
        checkapply.setId(id);

        checkapply.setItemid(itemid);
        checkapply.setName(name);
        checkapply.setObjective(objective);
        checkapply.setPosition(position);
        checkapply.setIsurgent(isurgent);
        checkapply.setNum(num);
        checkapply.setCreationtime(creationtime);
        checkapply.setCheckoperid(checkoperid);
        checkapply.setResultoperid(resultoperid);
        checkapply.setState(state);

        checkapplyDao.updateCheckapply(checkapply);
        findAll(request,response);
    }
    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Checkapply> checkapplys = checkapplyDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("checkapplyObjs",checkapplys);
        request.getRequestDispatcher("/system/displaycheckapply.jsp").forward(request,response);
    }

    protected void findCheckapplyById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int mediid = Integer.parseInt(request.getParameter("mediid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Checkapply checkapply= checkapplyDao.findCheckapplyByID(mediid);

        //3.跳转到修改显示页面
        request.setAttribute("medicalobj",checkapply);
        request.getRequestDispatcher("/system/updatecheckapply.jsp").forward(request,response);
    }

    protected void deleteCheckapplyById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int mediid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        checkapplyDao.deleteCheckapply(mediid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }
}

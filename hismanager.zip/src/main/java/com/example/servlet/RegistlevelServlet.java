package com.example.servlet;

import com.example.dao.RegistlevelDao;
import com.example.model.Registlevel;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "RegistlevelServlet", value = "/RegistlevelServlet")
public class RegistlevelServlet extends HttpServlet {

    RegistlevelDao registlevelDao = new RegistlevelDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){

            addRegistlevel(request,response);
        }else if("updatemethod".equals(methodname)){
            updateRegistlevel(request, response);

        }else if("deletemethod".equals(methodname)){
            deleteRegistlevelId(request, response);

        }else if("findid".equals(methodname)){
            findRegistlevelId(request, response);

        }else if ("cancelmethod".equals(methodname)) {

            cancelmethod(request, response);

        }else{

            findall(request,response);
        }
    }

    protected void addRegistlevel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String registCode = request.getParameter("registcode");
        String registName = request.getParameter("registname");
        int sequenceNo = Integer.parseInt(request.getParameter("sequenceno"));
        String registFee = request.getParameter("registfee");
        int registQuota = Integer.parseInt(request.getParameter("registquota"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        Registlevel registlevel = new Registlevel();

        registlevel.setRegistcode(registCode);
        registlevel.setRegistname(registName);
        registlevel.setSequenceno(sequenceNo);
        registlevel.setRegistfee(registFee);
        registlevel.setRegistquota(registQuota);
        registlevel.setDelmark(delMark);


        registlevelDao.addRegistlevel(registlevel);

        findall(request,response);

    }

    protected void updateRegistlevel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String registCode = request.getParameter("registcode");
        String registName = request.getParameter("registname");
        int s2 = Integer.parseInt(request.getParameter("sequenceno"));
        String registFee = request.getParameter("registfee");
        int registQuota = Integer.parseInt(request.getParameter("registquota"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        Registlevel registlevel = new Registlevel();
        registlevel.setId(id);
        registlevel.setRegistcode(registCode);
        registlevel.setRegistname(registName);
        registlevel.setSequenceno(s2);
        registlevel.setRegistfee(registFee);
        registlevel.setRegistquota(registQuota);
        registlevel.setDelmark(delMark);

        registlevelDao.updateRegistlevel(registlevel);

        findall(request,response);

    }

    protected void findall(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Registlevel> registlevels = registlevelDao.findall();

        request.setAttribute("registlevelObjs", registlevels);
        request.getRequestDispatcher("/system/displayregistlevel.jsp").forward(request, response);

    }

    protected void findRegistlevelId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("sssid"));

        Registlevel registlevel = registlevelDao.findRegistlevelId(sssid);

        request.setAttribute("sssobj", registlevel);

        request.getRequestDispatcher("/system/updateregistlevel.jsp").forward(request, response);

    }

    protected void deleteRegistlevelId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("did"));

        registlevelDao.deleteRegistlevel(sssid);

        findall(request, response);
    }

    protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("did"));

        registlevelDao.cancelRegistlevel(sssid);

        findall(request,response);
    }
}
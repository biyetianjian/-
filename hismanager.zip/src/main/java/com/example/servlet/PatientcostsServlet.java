package com.example.servlet;

import com.example.dao.DepartmentDao;
import com.example.dao.PatientcostsDao;
import com.example.dao.RegisterDao;
import com.example.dao.UserDao;
import com.example.model.Department;
import com.example.model.Patientcosts;
import com.example.model.Register;
import com.example.model.User;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "PatientcostsServlet", value = "/PatientcostsServlet")
public class PatientcostsServlet extends HttpServlet {

    PatientcostsDao patientcostsDao = new PatientcostsDao();
    RegisterDao  registerDao = new RegisterDao();
    UserDao userDao = new UserDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }



    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {

            addPatientcosts(request, response);
        }else if("cancelmethod".equals(methodname)){
            //删除操作
            cancelPatientcostsById(request,response);
        } else if ("findid".equals(methodname)) {
            findPatientcostsById(request, response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        }else{
            findAll(request,response);
            }
        }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Register> registers = registerDao.findALL();
        request.setAttribute("registerObjs",registers);
        List<User> users = userDao.findAll();
        request.setAttribute("userObjs",users);

        //2.存储部门信息

        //List<DepartmentLevel> departmentLevels = departmentLevelDao.findAll();
        //2.存储部门信息
        //request.setAttribute("departmentLevelObjs",departmentLevels);
        request.getRequestDispatcher("/system/addpatientcosts.jsp").forward(request,response);
    }



        protected void addPatientcosts (HttpServletRequest request, HttpServletResponse response) throws
        ServletException, IOException {

            int c1 = Integer.parseInt(request.getParameter("registid"));
            int c2 = Integer.parseInt(request.getParameter("itemid"));
            int c3 = Integer.parseInt(request.getParameter("itemtype"));
            String c4 = request.getParameter("name");
            int c5 = Integer.parseInt(request.getParameter("unitprice"));
            int c6 = Integer.parseInt(request.getParameter("amount"));
            int c9 = Integer.parseInt(request.getParameter("registerid"));
            int c10 = Integer.parseInt(request.getParameter("createoperid"));

            int c11 = Integer.parseInt(request.getParameter("feetype"));
            int c12 = Integer.parseInt(request.getParameter("retmark"));
            String c13 = request.getParameter("retdate");
            Patientcosts patientcosts = new Patientcosts();
            patientcosts.setRegistid(c1);
            patientcosts.setItemid(c2);
            patientcosts.setItemtype(c3);
            patientcosts.setName(c4);
            patientcosts.setUnitprice(c5);
            patientcosts.setAmount(c6);
            patientcosts.setRegisterid(c9);
            patientcosts.setCreateoperid(c10);
            patientcosts.setFeetype(c11);
            patientcosts.setRetmark(c12);
            patientcosts.setRetdate(c13);

            patientcostsDao.addPatientcosts(patientcosts);


            findAll(request,response);
        }

        /**
         * 功能：查询科室信息
         * @param request
         * @param response
         * @throws ServletException
         * @throws IOException
         */
        protected void findAll (HttpServletRequest request, HttpServletResponse response) throws
        ServletException, IOException {

            List<Patientcosts> patientcostss = patientcostsDao.findALL();

            request.setAttribute("patientcostsObjs", patientcostss);
            request.getRequestDispatcher("/system/displaypatientcosts.jsp").forward(request, response);

        }
        protected void findPatientcostsById (HttpServletRequest request, HttpServletResponse response) throws
        ServletException, IOException {
            //1.获取科室编号
            int patid = Integer.parseInt(request.getParameter("patid"));
            //2.调用数据库访问层中的根据科室编号查询科室信息的方法
            Patientcosts patientcosts = patientcostsDao.findPatientcostsByID(patid);

            //3.跳转到修改显示页面

        }

        /**
         * 功能：根据科室编号查询科室信息
         * @param request
         * @param response
         * @throws ServletException
         * @throws IOException
         */
        protected void cancelPatientcostsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            //1.获取科室编号
            int patid = Integer.parseInt(request.getParameter("did"));
            //2.调用数据库访问层中的根据科室编号删除科室信息的方法
            patientcostsDao.cancelPatientcosts(patid);
            //3.跳转到修改显示页面
            findAll(request,response);
        }

    }


package com.example.servlet;

import com.example.dao.MedicalrecordDao;
import com.example.dao.PrescriptionDao;
import com.example.dao.RegisterDao;
import com.example.dao.UserDao;
import com.example.model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "PrescriptionServlet", value = "/PrescriptionServlet")
public class PrescriptionServlet extends HttpServlet {

    //2.创建数据库访问层对象
    PrescriptionDao prescriptionDao = new PrescriptionDao();
    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();
    RegisterDao registerDao = new RegisterDao();
    UserDao userDao = new UserDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     *            添加方法的参数名：addmethod
     *            修改：    updatemethod
     *            删除：    deletemethod
     *            根据主键查询科室信息: findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addPrescription(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updatePrescription(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除操作
            deletePrescriptionById(request,response);
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findPrescriptionById(request,response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        }else{
            //执行查询所有记录
            findAll(request,response);
        }

    }

    /**
     * 功能：前端控制器--添加科室操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addPrescription(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (medicalid ,registlid ,userid ,prescriptionname ,prescriptiontime ,prescriptionstate)
        int medicalid = Integer.parseInt(request.getParameter("medicalid"));
        int registlid = Integer.parseInt(request.getParameter("registlid"));
        int userid = Integer.parseInt(request.getParameter("userid"));
        String prescriptionname = request.getParameter("prescriptionname");
        String prescriptiontime = request.getParameter("prescriptiontime");
        int prescriptionstate = Integer.parseInt(request.getParameter("prescriptionstate"));

        //创建对象

        Prescription prescription = new Prescription();
        prescription.setMedicalid(medicalid);
        prescription.setRegistlid(registlid);
        prescription.setUserid(userid);
        prescription.setPrescriptionname(prescriptionname);
        prescription.setPrescriptiontime(prescriptiontime);
        prescription.setPrescriptionstate(prescriptionstate);


        //3.调用数据库访问层中的添加方法
        prescriptionDao.addPrescription(prescription);

        //4.跳转到成功提示页面
        findAll(request,response);

    }

    protected void updatePrescription(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        int medicalid = Integer.parseInt(request.getParameter("medicalid"));
        int registlid = Integer.parseInt(request.getParameter("registlid"));
        int userid = Integer.parseInt(request.getParameter("userid"));
        String prescriptionname = request.getParameter("prescriptionname");
        String prescriptiontime = request.getParameter("prescriptiontime");
        int prescriptionstate = Integer.parseInt(request.getParameter("prescriptionstate"));

        Prescription prescription = new Prescription();
        prescription.setId(id);
        prescription.setMedicalid(medicalid);
        prescription.setRegistlid(registlid);
        prescription.setUserid(userid);
        prescription.setPrescriptionname(prescriptionname);
        prescription.setPrescriptiontime(prescriptiontime);
        prescription.setPrescriptionstate(prescriptionstate);

        prescriptionDao.updatePrescription(prescription);

        findAll(request,response);

    }

    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Prescription> prescriptions = prescriptionDao.findAll();
        request.setAttribute("prescriptionObjs",prescriptions);
        request.getRequestDispatcher("/system/displayprescription.jsp").forward(request,response);
    }

    protected void findPrescriptionById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int mediid = Integer.parseInt(request.getParameter("mediid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Prescription prescription= prescriptionDao.findPrescriptionByID(mediid);

        //3.跳转到修改显示页面
        request.setAttribute("preobj",prescription);
        request.getRequestDispatcher("/system/updateprescription.jsp").forward(request,response);
    }

    protected void deletePrescriptionById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int mediid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        prescriptionDao.deletePrescription(mediid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        request.setAttribute("medicalrecordObjs", medicalrecords);
        List<Register> registers = registerDao.findALL();
        request.setAttribute("registerObjs",registers);
        List<User> users = userDao.findAll();
        request.setAttribute("userObjs", users);

        request.getRequestDispatcher("/system/addprescription.jsp").forward(request, response);
    }
}

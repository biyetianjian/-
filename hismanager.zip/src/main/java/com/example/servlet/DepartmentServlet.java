package com.example.servlet;

import com.example.dao.DepartmentDao;
import com.example.model.Department;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DepartmentServlet", value = "/DepartmentServlet")
public class DepartmentServlet extends HttpServlet {

    DepartmentDao departmentDao = new DepartmentDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){

            addDepartment(request,response);
        }else if("updatemethod".equals(methodname)){

            updateDepartment(request,response);
        }else if("deletemethod".equals(methodname)){

            deleteDepartmentById(request,response);
        }else if("findid".equals(methodname)){


            findDepartmentById(request,response);
        }else if ("cancelmethod".equals(methodname)) {

            cancelmethod(request, response);
        }else{

            findAll(request,response);
        }
    }

    protected void addDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String departmentCode = request.getParameter("deptcode");
        String departmentName = request.getParameter("deptname");
        int departmentCid = Integer.parseInt(request.getParameter("deptcategoryid"));
        int departmentType = Integer.parseInt(request.getParameter("depttype"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        Department department = new Department();
        department.setDeptcode(departmentCode);
        department.setDeptname(departmentName);
        department.setDeptcategoryid(departmentCid);
        department.setDepttype(departmentType);
        department.setDelmark(delMark);

        departmentDao.addDepartment(department);

        findAll(request,response);

    }

    protected void updateDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String departmentCode = request.getParameter("deptcode");
        String departmentName = request.getParameter("deptname");
        int departmentCid = Integer.parseInt(request.getParameter("deptcategoryid"));
        int departmentType = Integer.parseInt(request.getParameter("depttype"));
        int delMark = Integer.parseInt(request.getParameter("delmark"));

        Department department = new Department();
        department.setId(id);
        department.setDeptcode(departmentCode);
        department.setDeptname(departmentName);
        department.setDeptcategoryid(departmentCid);
        department.setDepttype(departmentType);
        department.setDelmark(delMark);

        departmentDao.updateDepartment(department);

        findAll(request,response);

    }

    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<Department> departments = departmentDao.findAll();

        request.setAttribute("departmentObjs",departments);

        request.getRequestDispatcher("/system/displaydepartment.jsp").forward(request,response);
    }

    protected void findDepartmentById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int deptid = Integer.parseInt(request.getParameter("deptid"));

            Department department= departmentDao.findDeparmtnByID(deptid);

            request.setAttribute("deptobj",department);
        request.getRequestDispatcher("/system/updatedepartment.jsp").forward(request,response);
    }

    protected void deleteDepartmentById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int deptid = Integer.parseInt(request.getParameter("did"));

        departmentDao.deleteDepartment(deptid);

        findAll(request,response);
    }

    protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int sssid = Integer.parseInt(request.getParameter("did"));

        departmentDao.cancelDepartment(sssid);

        findAll(request,response);
    }

}

package com.example.servlet;

import com.example.dao.DrugsDao;
import com.example.dao.PrescriptionDao;
import com.example.dao.PrescriptiondetailedDao;
import com.example.model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "PrescriptiondetailedServlet", value = "/PrescriptiondetailedServlet")
public class PrescriptiondetailedServlet extends HttpServlet {

    PrescriptiondetailedDao prescriptiondetailedDao = new PrescriptiondetailedDao();
    PrescriptionDao prescriptionDao = new PrescriptionDao();
    DrugsDao drugsDao = new DrugsDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);

    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){

            addPrescriptiondetailed(request,response);
        }else if("updatemethod".equals(methodname)){
            updatePrescriptiondetailed(request,response);
        }else if("deletemethod".equals(methodname)){
            deletePrescriptiondetailedById(request,response);
        }else if("findid".equals(methodname)){
            findPrescriptiondetailedById(request,response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        }else{

            findAll(request,response);
        }
    }

    protected void addPrescriptiondetailed(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       int p1  = Integer.parseInt(request.getParameter("prescriptionid"));
       int p2 = Integer.parseInt(request.getParameter("drugsid"));
        String p3 = request.getParameter("drugsusage");
        String p4 = request.getParameter("dosage");
        String p5 = request.getParameter("frequency");
        int p6 = Integer.parseInt(request.getParameter("amount"));
        int p7 = Integer.parseInt(request.getParameter("state"));

        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();

        prescriptiondetailed.setPrescriptionid(p1);
        prescriptiondetailed.setDrugsid(p2);
        prescriptiondetailed.setDrugsusage(p3);
        prescriptiondetailed.setDosage(p4);
        prescriptiondetailed.setFrequency(p5);
        prescriptiondetailed.setAmount(p6);
        prescriptiondetailed.setState(p7);
        //3.调用数据库访问层中的添加方法
        prescriptiondetailedDao.addPrescriptiondetailed(prescriptiondetailed);

        //4.跳转到成功提示页面
        findAll(request,response);

    }

    protected void updatePrescriptiondetailed(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        int p1  = Integer.parseInt(request.getParameter("prescriptionid"));
        int p2 = Integer.parseInt(request.getParameter("drugsid"));
        String p3 = request.getParameter("drugsusage");
        String p4 = request.getParameter("dosage");
        String p5 = request.getParameter("frequency");
        int p6 = Integer.parseInt(request.getParameter("amount"));
        int p7 = Integer.parseInt(request.getParameter("state"));

        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setId(id);
        prescriptiondetailed.setPrescriptionid(p1);
        prescriptiondetailed.setDrugsid(p2);
        prescriptiondetailed.setDrugsusage(p3);
        prescriptiondetailed.setDosage(p4);
        prescriptiondetailed.setFrequency(p5);
        prescriptiondetailed.setAmount(p6);
        prescriptiondetailed.setState(p7);

        //3.调用数据库访问层中的修改方法
        prescriptiondetailedDao.updatePrescriptiondetailed(prescriptiondetailed);

        //4.跳转到显示页面
        findAll(request,response);

    }

    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Prescriptiondetailed>  prescriptiondetaileds  = prescriptiondetailedDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("prescriptiondetailedObjs", prescriptiondetaileds);
        request.getRequestDispatcher("/system/displayprescriptiondetailed.jsp").forward(request,response);
    }
    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findPrescriptiondetailedById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int preid = Integer.parseInt(request.getParameter("preid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Prescriptiondetailed prescriptiondetailed= prescriptiondetailedDao.findPrescriptiondetailedByID(preid);

        //3.跳转到修改显示页面
        request.setAttribute("preobj",prescriptiondetailed);
        request.getRequestDispatcher("/system/updateprescriptiondetailed.jsp").forward(request,response);
    }

    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deletePrescriptiondetailedById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int preid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        prescriptiondetailedDao.deletePrescriptiondetailed(preid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Drugs> drugss = drugsDao.findAll();
        request.setAttribute("drugsObjs",drugss);
        List<Prescription> prescriptions = prescriptionDao.findAll();
        request.setAttribute("prescriptionObjs",prescriptions);

        request.getRequestDispatcher("/system/addprescriptiondetailed.jsp").forward(request, response);
    }
}

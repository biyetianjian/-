package com.example.servlet;

import com.example.dao.DiseaseDao;
import com.example.dao.DisecategoryDao;
import com.example.model.Disease;
import com.example.model.Disecategory;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DiseaseServlet", value = "/DiseaseServlet")
public class DiseaseServlet extends HttpServlet {

    //创建对象
    DiseaseDao diseaseDao = new DiseaseDao();
    DisecategoryDao disecategoryDao = new DisecategoryDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }


    /**
     *  执行添加，修改，删除，查询
     *         添加：addmethod
     *         修改：updatemethod
     *         删除：deletemethod
     *         查询：findRegitserByIdmethod
     *         默认：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)) {
            //添加
            addDisease(request, response);
        }else if("updatemethod".equals(methodname)){
            //修改
            updateDisease(request,response);


        }else if("deletemethod".equals(methodname)){
            //删除
            delDiseaseID(request,response);

        }else if ("findid".equals(methodname)){
            //查询id
            findid(request,response);

        }else if ("addinput".equals(methodname)){
            //根据主键查询数据表信息
            addinput(request,response);
        }else if ("cancelmethod".equals(methodname)){
            //作废id
            cancelDiseaseID(request,response);
        } else {
            //默认
            findAll(request,response);
        }
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<Disecategory> disecategories = disecategoryDao.findAll();
        request.setAttribute("dcObjs",disecategories);
        request.getRequestDispatcher("/system/adddisease.jsp").forward(request,response);
    }
    /**
     * 添加
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addDisease(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取信息(diseasecode,diseasename,diseaseicd,disecategoryid,delmark,deldate)
        String diseaseCode = request.getParameter("diseasecode");
        String diseaseName = request.getParameter("diseasename");
        String diseaseIcd = request.getParameter("diseaseicd");
        Integer diseaseDicaid = Integer.parseInt(request.getParameter("disecategoryid"));
        Integer diseaseMark = Integer.parseInt(request.getParameter("delmark"));
        String diseaseDate = request.getParameter("deldate");

        //创建对象
        Disease disease = new Disease();
        disease.setDiseasecode(diseaseCode);
        disease.setDiseasename(diseaseName);
        disease.setDiseaseicd(diseaseIcd);
        disease.setDisecategoryid(diseaseDicaid);
        disease.setDelmark(diseaseMark);
        disease.setDeldate(diseaseDate);

        //调用添加方法
        diseaseDao.addDisease(disease);

        findAll(request,response);

    }

    //修改
    protected void updateDisease(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取信息(diseasecode,diseasename,diseaseicd,disecategoryid,delmark,deldate)
        int diseaseId = Integer.parseInt(request.getParameter("id"));
        String diseaseCode = request.getParameter("diseasecode");
        String diseaseName = request.getParameter("diseasename");
        String diseaseIcd = request.getParameter("diseaseicd");
        Integer diseaseDicaid = Integer.parseInt(request.getParameter("disecategoryid"));
        Integer diseaseMark = Integer.parseInt(request.getParameter("delmark"));
        String diseaseDate = request.getParameter("deldate");

        //创建对象
        Disease disease = new Disease();
        disease.setId(diseaseId);
        disease.setDiseasecode(diseaseCode);
        disease.setDiseasename(diseaseName);
        disease.setDiseaseicd(diseaseIcd);
        disease.setDisecategoryid(diseaseDicaid);
        disease.setDelmark(diseaseMark);
        disease.setDeldate(diseaseDate);

        //调用添加方法
        diseaseDao.updateDisease(disease);

        //跳转显示页面
        findAll(request,response);

    }

    //删除
    protected void delDiseaseID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dsid = Integer.parseInt(request.getParameter("dsid"));

        diseaseDao.deleteDisease(dsid);

        findAll(request,response);
    }

    //查询
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        //调用查询方法
        List<Disease> diseases = diseaseDao.findAll();

        //跳到显示页面
        request.setAttribute("diseaseObjs",diseases);
        request.getRequestDispatcher("/system/displaydisease.jsp").forward(request,response);
    }

    protected void findid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dsid = Integer.parseInt(request.getParameter("dsid"));

        Disease disease = diseaseDao.findDiseaseID(dsid);

        request.setAttribute("dsobj",disease);
        request.getRequestDispatcher("/system/updatedisease.jsp").forward(request,response);
    }

    //逻辑删除
    protected void cancelDiseaseID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int dsid = Integer.parseInt(request.getParameter("dsid"));

        diseaseDao.cancelDisease(dsid);

        findAll(request,response);
    }



}

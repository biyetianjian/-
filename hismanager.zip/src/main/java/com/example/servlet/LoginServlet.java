package com.example.servlet;

import com.example.dao.LoginDao;
import com.example.model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

/**
 * 前端控制器用户登录操作
 */
@WebServlet(name = "LoginServlet", value = "/LoginServlet")
public class LoginServlet extends HttpServlet {
    LoginDao loginDao = new LoginDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**
     * 登录操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username =request.getParameter("username");
        String password = request.getParameter("password");
        int role = Integer.parseInt(request.getParameter("role"));

        User user = loginDao.findUser(username,role);
        if(user!=null){
            if(password.equals(user.getPassword())){
                HttpSession session = request.getSession();
                session.setAttribute("realname",user.getRealname());
                if(role == 1){
                    //跳转到系统管理员界面
                    response.sendRedirect(request.getContextPath() + "/admin/main.jsp");
                }else if(role==2){
                    //跳转到护士操作界面
                    response.sendRedirect(request.getContextPath() + "/nurse/main.jsp");
                }else if(role ==3){
                    response.sendRedirect(request.getContextPath() + "/doctor/main.jsp");
                }else if(role==4){
                    //跳转到检查员操作界面
                    response.sendRedirect(request.getContextPath() + "/inspector/main.jsp");
                }else if(role==5){
                    //跳转到财务管理员操作界面
                    response.sendRedirect(request.getContextPath() + "/finance/main.jsp");
                }
            }else{
                request.setAttribute("error","密码输入有误！");
                request.getRequestDispatcher("/login.jsp").forward(request,response);
            }
        }else{
            request.setAttribute("error","账户不存在！");
            request.getRequestDispatcher("/login.jsp").forward(request,response);
        }
    }
}

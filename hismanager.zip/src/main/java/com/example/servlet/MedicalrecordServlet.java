package com.example.servlet;

import com.example.dao.MedicalrecordDao;
import com.example.dao.RegisterDao;
import com.example.model.Drugs;
import com.example.model.Medicalrecord;
import com.example.model.Register;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "MedicalrecordServlet", value = "/MedicalrecordServlet")
public class MedicalrecordServlet extends HttpServlet {
    MedicalrecordDao medicalrecordDao= new MedicalrecordDao();
    RegisterDao registerDao = new RegisterDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addMedicalrecord(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updateMedicalrecord(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除操作
            deleteMedicalrecordById(request,response);
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findMedicalrecordById(request,response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        }else{
            //执行查询所有记录
            findAll(request,response);
        }
    }
    protected void addMedicalrecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String caseNumber = request.getParameter("casenumber");
        int registId = Integer.parseInt(request.getParameter("registid"));
        String presentTreat = request.getParameter("presenttreat");
        String hiStory = request.getParameter("history");
        String alLergy = request.getParameter("allergy");
        String proPosal = request.getParameter("proposal");
        int caseState = Integer.parseInt(request.getParameter("casestate"));

        //创建Deparmtn对象
        Medicalrecord medicalrecord= new Medicalrecord();
        medicalrecord.setCasenumber(caseNumber);
        medicalrecord.setRegistid(registId);
        medicalrecord.setPresenttreat(presentTreat);
        medicalrecord.setHistory(hiStory);
        medicalrecord.setAllergy(alLergy);
        medicalrecord.setProposal(proPosal);
        medicalrecord.setCasestate(caseState);



        //3.调用数据库访问层中的添加方法
        medicalrecordDao.addMedicalrecord(medicalrecord);

        //4.跳转到成功提示页面
        findAll(request,response);

    }

    protected void updateMedicalrecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String caseNumber = request.getParameter("casenumber");
        int registId = Integer.parseInt(request.getParameter("registid"));
        String presentTreat = request.getParameter("presenttreat");
        String hiStory = request.getParameter("history");
        String alLergy = request.getParameter("allergy");
        String proPosal = request.getParameter("proposal");
        int caseState = Integer.parseInt(request.getParameter("casestate"));

        //创建Deparmtn对象
        Medicalrecord medicalrecord= new Medicalrecord();
        medicalrecord.setId(id);
        medicalrecord.setCasenumber(caseNumber);
        medicalrecord.setRegistid(registId);
        medicalrecord.setPresenttreat(presentTreat);
        medicalrecord.setHistory(hiStory);
        medicalrecord.setAllergy(alLergy);
        medicalrecord.setProposal(proPosal);
        medicalrecord.setCasestate(caseState);

        //3.调用数据库访问层中的修改方法
        medicalrecordDao.updateMedicalrecord(medicalrecord);

        //4.跳转到显示页面
        findAll(request,response);

    }
    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("medicalrecordObjs",medicalrecords);
        request.getRequestDispatcher("/system/displaymedicalrecord.jsp").forward(request,response);
    }
    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findMedicalrecordById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号medicalrecordsid=5
        int medicalrecordid = Integer.parseInt(request.getParameter("medicalrecordsid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Medicalrecord medicalrecord= medicalrecordDao.findMedicalrecordByID(medicalrecordid);

        //3.跳转到修改显示页面
        request.setAttribute("medicalrecordobj",medicalrecord);
        request.getRequestDispatcher("/system/updatemedicalrecord.jsp").forward(request,response);
    }
    /**
     * 功能：根据科室编号删除科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteMedicalrecordById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int medicalrecordid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        medicalrecordDao.deleteMedicalrecord(medicalrecordid);
        //3.跳转到修改显示页面
        findAll(request, response);

    }

        protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

            List<Register> registers = registerDao.findALL();
            request.setAttribute("registerObjs", registers);
            request.getRequestDispatcher("/system/addmedicalrecord.jsp").forward(request, response);
        }
    }


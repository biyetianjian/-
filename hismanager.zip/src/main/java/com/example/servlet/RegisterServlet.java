package com.example.servlet;

import com.example.dao.DepartmentDao;
import com.example.dao.UserDao;
import com.example.dao.RegisterDao;
import com.example.model.Department;
import com.example.model.User;
import com.example.model.Register;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "RegisterServlet", value = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    //创建对象
    RegisterDao registerDao = new RegisterDao();
    DepartmentDao departmentDao = new DepartmentDao();
    UserDao userDao = new UserDao();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**
     *  执行添加，修改，删除，查询
     *         添加：addmethod
     *         修改：updatemethod
     *         删除：deletemethod
     *         查询：findRegitserByIdmethod
     *         默认：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)) {
            //添加
            addRegister(request, response);
        }else if("updatemethod".equals(methodname)){
            //修改
            updateRegister(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除
            delRegisterID(request,response);

        }else if ("findid".equals(methodname)){
            //查询id
            findid(request,response);
        }else if ("addinput".equals(methodname)){
            //根据主键查询数据表信息
            addinput(request,response);
        }else if ("cancelmethod".equals(methodname)){
            //作废id
            cancelRegisterID(request,response);
        }else {
            //默认
            findAll(request,response);
        }


    }
    //查询科室信息
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<Department> departments = departmentDao.findAll();
        request.setAttribute("dpObjs",departments);
        List<User> users = userDao.findAll();
        request.setAttribute("uObjs",users);
        request.getRequestDispatcher("/system/addregister.jsp").forward(request,response);
    }


    /**
     * 添加
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void addRegister(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取信息 (casenumber,realname,gender,idnumber,birthdate,age,agetype,hpmeaddress
        //			deptid,userid,registtime,visitstate)

        String registerCode = request.getParameter("casenumber");
        String registerName = request.getParameter("realname");
        String registerGender = request.getParameter("gender");
        String registerNumber = request.getParameter("idnumber");
        String registerBirth = request.getParameter("birthdate");
        int registerAge = Integer.parseInt(request.getParameter("age"));
        String registerAgetype =request.getParameter("agetype");
        String registerHome = request.getParameter("homeaddress");
        int registerDept = Integer.parseInt(request.getParameter("deptid"));
        int registerUser = Integer.parseInt(request.getParameter("userid"));
        String registerTime = request.getParameter("registtime");
        int registerState = Integer.parseInt(request.getParameter("visitstate"));


        //创建对象
        Register register = new Register();

        register.setRealname(registerName);
        register.setGender(registerGender);
        register.setIdnumber(registerNumber);
        register.setBirthdate(registerBirth);
        register.setAge(registerAge);
        register.setAgetype(registerAgetype);
        register.setHomeaddress(registerHome);
        register.setDeptid(registerDept);
        register.setUserid(registerUser);
        register.setRegisttime(registerTime);
        register.setVisitstate(registerState);



        //调用添加方法
        registerDao.addRegister(register);

        //跳到显示页面
        findAll(request,response);

    }

    //修改
    protected void updateRegister(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取信息 (casenumber,realname,gender,idnumber,birthdate,age,agetype,hpmeaddress
        //			deptid,userid,registtime,visitstate)
        int registerId = Integer.parseInt(request.getParameter("id"));
        String registerCode = request.getParameter("casenumber");
        String registerName = request.getParameter("realname");
        String registerGender = request.getParameter("gender");
        String registerNumber = request.getParameter("idnumber");
        String registerBirth = request.getParameter("birthdate");
        int registerAge = Integer.parseInt(request.getParameter("age"));
        String registerAgetype =request.getParameter("agetype");
        String registerHome = request.getParameter("homeaddress");
        int registerDept = Integer.parseInt(request.getParameter("deptid"));
        int registerUser = Integer.parseInt(request.getParameter("userid"));
        String registerTime = request.getParameter("registtime");
        int registerState = Integer.parseInt(request.getParameter("visitstate"));


        //创建对象
        Register register = new Register();
        register.setId(registerId);

        register.setRealname(registerName);
        register.setGender(registerGender);
        register.setIdnumber(registerNumber);
        register.setBirthdate(registerBirth);
        register.setAge(registerAge);
        register.setAgetype(registerAgetype);
        register.setHomeaddress(registerHome);
        register.setDeptid(registerDept);
        register.setUserid(registerUser);
        register.setRegisttime(registerTime);
        register.setVisitstate(registerState);



        //调用修改方法
        registerDao.updateRegister(register);

        //跳到显示页面
        findAll(request,response);
    }

    //查询
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        //调用查询方法
        List<Register> registers = registerDao.findALL();

        //跳到显示页面
        request.setAttribute("registerObjs",registers);
        request.getRequestDispatcher("/system/displayregister.jsp").forward(request,response);
    }


    /**
     * 根据id查询信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int reid = Integer.parseInt(request.getParameter("reid"));

        Register register = registerDao.findRegisterID(reid);

        request.setAttribute("reobj",register);
        request.getRequestDispatcher("/system/updateregister.jsp").forward(request,response);

    }

    //删除
    protected void delRegisterID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int reid = Integer.parseInt(request.getParameter("reid"));

        registerDao.deleteRegister(reid);

        findAll(request,response);
    }

    //逻辑删除
    protected void cancelRegisterID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        int reid = Integer.parseInt(request.getParameter("reid"));

        registerDao.cancelRegister(reid);

        findAll(request,response);
    }

}

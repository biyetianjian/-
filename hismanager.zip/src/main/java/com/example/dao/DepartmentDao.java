package com.example.dao;

import com.example.model.Department;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDao {

    public boolean addDepartment(Department department){
        boolean flag = false;
        String sql ="insert into tbl_department(deptcode,deptname,deptcategoryid ,depttype,delmark) " +
                "values(?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,department.getDeptcode(),department.getDeptname(),
                department.getDeptcategoryid(),department.getDepttype(),department.getDelmark());
    }

    public boolean updateDepartment(Department department){
        boolean flag = false;
        String sql ="update tbl_department set deptname=?,deptcategoryid=?,depttype=?,delmark=? where id=?";
        flag = DBCPUtil.execUpdate(sql,department.getDeptname(),department.getDeptcategoryid(),
                department.getDepttype(),department.getDelmark(),department.getId());
        return flag;
    }

    public List<Department> findAll(){
        List<Department> departments = new ArrayList<>();
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,deptcode,deptname,deptcategoryid,depttype,delmark from tbl_department where delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Department department = null;
            while(rs.next()){
                department = new Department();
                int id= rs.getInt("id");
                String deptcode = rs.getString("deptcode");
                String deptname = rs.getString("deptname");
                int deptcategoryid = rs.getInt("deptcategoryid");
                int depttype = rs.getInt("depttype");
                int delmark = rs.getInt("delmark");

                department.setId(id);
                department.setDeptcode(deptcode);
                department.setDeptname(deptname);
                department.setDeptcategoryid(deptcategoryid);
                department.setDepttype(depttype);
                department.setDelmark(delmark);

                departments.add(department);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return departments;
    }


    public boolean deleteDepartment(int id){
        boolean flag = false;
        String sql ="delete from tbl_department where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }


    public boolean cancelDepartment(int id){
        String sql = "update tbl_department set delmark=0,deldate=now() where id=?";
        return DBCPUtil.execUpdate(sql,id);
    }

    public Department findDeparmtnByID(int deptid){
        Department department = new Department();

        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,deptcode,deptname,deptcategoryid,depttype,delmark from tbl_department where id=? and delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,deptid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id= rs.getInt("id");
                String deptcode = rs.getString("deptcode");
                String deptname = rs.getString("deptname");
                int deptcategoryid = rs.getInt("deptcategoryid");
                int depttype = rs.getInt("depttype");
                int delmark = rs.getInt("delmark");

                department.setId(id);
                department.setDeptcode(deptcode);
                department.setDeptname(deptname);
                department.setDeptcategoryid(deptcategoryid);
                department.setDepttype(depttype);
                department.setDelmark(delmark);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return department;
    }
}

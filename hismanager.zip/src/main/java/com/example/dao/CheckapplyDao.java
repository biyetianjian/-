package com.example.dao;

import com.example.model.Checkapply;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */
public class CheckapplyDao {

    /**
     * 添加科室操作
     * @param checkapply
     * @return
     */
    public boolean addCheckapply(Checkapply checkapply){
        boolean flag = false;
        String sql ="insert into tbl_checkapply(itemid,name,objective,position,isurgent,num,creationtime,checkoperid,resultoperid,state,checkresult) " +
                "values(?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,checkapply.getItemid(),checkapply.getName(),checkapply.getObjective(),checkapply.getPosition(),checkapply.getIsurgent(),
                checkapply.getNum(),checkapply.getCreationtime(),checkapply.getCheckoperid(),checkapply.getResultoperid(),
                checkapply.getState(),checkapply.getCheckresult());
    }
    public boolean updateCheckapply(Checkapply checkapply){
        boolean flag = false;
        String sql ="update tbl_checkapply set creationtime=?,checkoperid=?,resultoperid=?,state=?,checkresult=? where id=?";

        flag = DBCPUtil.execUpdate(sql,checkapply.getCreationtime(),checkapply.getCheckoperid(),
                checkapply.getResultoperid(),checkapply.getState(),checkapply.getCheckresult(),checkapply.getId());
        return flag;
    }

    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<Checkapply> findAll(){
        List<Checkapply> checkapplys = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,itemid,name,objective,position,isurgent,num,creationtime,checkoperid,resultoperid,state,checkresult from tbl_checkapply";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Checkapply checkapply = null;
            while(rs.next()){
                checkapply = new Checkapply();
                int id = rs.getInt("id");
                int itemid = rs.getInt("itemid");
                String name = rs.getString("name");
                String objective = rs.getString("objective");
                String position = rs.getString("position");
                int isurgent = rs.getInt("isurgent");
                int num = rs.getInt("num");
                String creationtime = rs.getString("creationtime");
                int checkoperid = rs.getInt("checkoperid");
                int resultoperid = rs.getInt("resultoperid");
                int state = rs.getInt("state");
                String checkresult = rs.getString("checkresult");



                //每行记录封装为一个对象
                checkapply.setId(id);
                checkapply.setItemid(itemid);
                checkapply.setName(name);
                checkapply.setObjective(objective);
                checkapply.setPosition(position);
                checkapply.setIsurgent(isurgent);
                checkapply.setNum(num);
                checkapply.setCreationtime(creationtime);
                checkapply.setCheckoperid(checkoperid);
                checkapply.setResultoperid(resultoperid);
                checkapply.setState(state);
                checkapply.setCheckresult(checkresult);


                //将对象添加到List集合中
                checkapplys.add(checkapply);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }
        return checkapplys;
    }

    public Checkapply findCheckapplyByID(int mediid){
        Checkapply checkapply = new Checkapply();
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,itemid,name,objective,position,isurgent,num,creationtime," +
                "checkoperid,resultoperid,state from tbl_checkapply where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,mediid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id = rs.getInt("id");
                int itemid = rs.getInt("itemid");
                String name = rs.getString("name");
                String objective = rs.getString("objective");
                String position = rs.getString("position");
                int isurgent = rs.getInt("isurgent");
                int num = rs.getInt("num");
                String creationtime = rs.getString("creationtime");
                int checkoperid = rs.getInt("checkoperid");
                int resultoperid = rs.getInt("resultoperid");
                int state = rs.getInt("state");

                checkapply.setId(id);
                checkapply.setItemid(itemid);
                checkapply.setName(name);
                checkapply.setObjective(objective);
                checkapply.setPosition(position);
                checkapply.setIsurgent(isurgent);
                checkapply.setNum(num);
                checkapply.setCreationtime(creationtime);
                checkapply.setCheckoperid(checkoperid);
                checkapply.setResultoperid(resultoperid);
                checkapply.setState(state);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return checkapply;
    }
    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteCheckapply(int id) {
        boolean flag = false;
        String sql = "delete from tbl_checkapply where id =?";
        // String sql = "update tbl_checkapply set flag = 1,flag=now() where id = ?";
        flag = DBCPUtil.execUpdate(sql, id);
        return flag;
    }
}


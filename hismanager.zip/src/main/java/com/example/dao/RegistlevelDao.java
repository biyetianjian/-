package com.example.dao;

import com.example.util.DBCPUtil;
import com.example.model.Registlevel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegistlevelDao {

    public boolean addRegistlevel(Registlevel registlevel){
        boolean flag = false;
        String sql ="insert into tbl_registlevel(registcode,registname,sequenceno,registfee,registquota,delmark,deldate) " +
                "values(?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,registlevel.getRegistcode(),registlevel.getRegistname(),
                registlevel.getSequenceno(),registlevel.getRegistfee(),registlevel.getRegistquota(),registlevel.getDelmark(),registlevel.getDeldate());
    }


    public boolean updateRegistlevel(Registlevel registlevel){
        boolean flag = false;
        String sql ="update tbl_registlevel set registcode=?,registname=?,sequenceNo=?,registFee=?,registQuota=?,delMark=?,delDate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,registlevel.getRegistcode(),registlevel.getRegistname(),
                registlevel.getSequenceno(),registlevel.getRegistfee(),registlevel.getRegistquota(),registlevel.getDelmark(),registlevel.getDeldate(),registlevel.getId());
        return flag;
    }


    public List<Registlevel> findall(){
        List<Registlevel> registlevels = new ArrayList<>();
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registcode,registname,sequenceno,registfee,registquota,delmark,deldate from tbl_registlevel where delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Registlevel registlevel = null;
            while (rs.next()){
                registlevel = new Registlevel();
                int id= rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                String registfee = rs.getString("registfee");
                int registquota = rs.getInt("registquota");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                registlevel.setId(id);
                registlevel.setRegistcode(registcode);
                registlevel.setRegistname(registname);
                registlevel.setSequenceno(sequenceno);
                registlevel.setRegistfee(registfee);
                registlevel.setRegistquota(registquota);
                registlevel.setDelmark(delmark);
                registlevel.setDeldate(deldate);

                registlevels.add(registlevel);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return registlevels;
    }

    public boolean deleteRegistlevel(int id){
        boolean flag = false;
        String sql ="delete from tbl_registlevel where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    public boolean cancelRegistlevel(int id){
        String sql = "update tbl_registlevel set delmark=0,deldate=now() where id=?";
        return DBCPUtil.execUpdate(sql,id);
    }

    public Registlevel findRegistlevelId(int sssid){
        Registlevel registlevel = new Registlevel();

        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registcode,registname,sequenceno,registfee,registquota,delmark,deldate from tbl_registlevel where id=? and delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,sssid);

            rs = pstmt.executeQuery();

            if (rs.next()){

                int id= rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                String registfee = rs.getString("registfee");
                int registquota = rs.getInt("registquota");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                registlevel.setId(id);
                registlevel.setRegistcode(registcode);
                registlevel.setRegistname(registname);
                registlevel.setSequenceno(sequenceno);
                registlevel.setRegistfee(registfee);
                registlevel.setRegistquota(registquota);
                registlevel.setDelmark(delmark);
                registlevel.setDeldate(deldate);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return registlevel;
    }

}

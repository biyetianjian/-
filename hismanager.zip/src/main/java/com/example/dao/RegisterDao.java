package com.example.dao;


import com.example.model.Department;
import com.example.model.User;
import com.example.model.Register;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegisterDao {

    //添加
    public boolean addRegister(Register register){
        boolean flag = false;
        String sql = "insert into tbl_register(realname,gender,idnumber,birthdate,age,agetype," +
                "homeaddress,deptid,userid,registtime,visitstate) values(?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql, register.getRealname(),register.getGender(),
                register.getIdnumber(),register.getBirthdate(),register.getAge(),register.getAgetype(),
                register.getHomeaddress(),register.getDeptid(),register.getUserid(),register.getRegisttime(),
                register.getVisitstate());

    }

    /**
     * 修改
     * @param
     * @return
     */
    public boolean updateRegister(Register register){
        boolean flag = false;
        String sql = "update tbl_Register set realname=?,gender=?,idnumber=?,birthdate=?,age=?" +
                ",agetype=?,homeaddress=?,deptid=?,userid=?,registtime=?,visitstate=? where id = ?";
        flag = DBCPUtil.execUpdate(sql,register.getRealname(),register.getGender(),
                register.getIdnumber(),register.getBirthdate(),register.getAge(),register.getAgetype(),
                register.getHomeaddress(),register.getDeptid(),register.getUserid(),register.getRegisttime(),
                register.getVisitstate(),register.getId());
        return flag;
    }

    //删除
    public  boolean deleteRegister(int id){
        boolean flag = false;
        String sql = "delete from tbl_register where id=?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;

    }

    /**
     * 查询id
     */

    public Register findRegisterID(int reid){
        Register register = new Register();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,realname,gender,idnumber,birthdate,age,registtime,agetype,homeaddress,deptid,userid," +
                "visitstate from tbl_register where id=? ";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,reid);

            rs = pstmt.executeQuery();
            if (rs.next()){
                int id = rs.getInt("id");

                String realname = rs.getString("realname");
                String gender = rs.getString("gender");
                String idnumber = rs.getString("idnumber");
                String birthdate = rs.getString("birthdate");
                int age = rs.getInt("age");
                String agetype = rs.getString("agetype");
                String homeaddress = rs.getString("homeaddress");
                int deptid = rs.getInt("deptid");
                int userid = rs.getInt("userid");
                String registtime = rs.getString("registtime");
                int visitstate = rs.getInt("visitstate");

                register.setId(id);

                register.setRealname(realname);
                register.setGender(gender);
                register.setIdnumber(idnumber);
                register.setBirthdate(birthdate);
                register.setAge(age);
                register.setAgetype(agetype);
                register.setHomeaddress(homeaddress);
                register.setDeptid(deptid);
                register.setUserid(userid);
                register.setRegisttime(registtime);
                register.setVisitstate(visitstate);

            }
        } catch (SQLException e) {
            e.printStackTrace();

        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return register;
    }

    //查询所有
    public List<Register> findALL(){
        List<Register> registers = new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,realname,gender,idnumber,birthdate,age,agetype,homeaddress,deptid,userid," +
                "registtime,visitstate from tbl_register";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Register register = null;
            while (rs.next()){
                register = new Register();
                int id = rs.getInt("id");

                String realname = rs.getString("realname");
                String gender = rs.getString("gender");
                String idnumber = rs.getString("idnumber");
                String birthdate = rs.getString("birthdate");
                int age = rs.getInt("age");
                String agetype = rs.getString("agetype");
                String homeaddress = rs.getString("homeaddress");
                int deptid = rs.getInt("deptid");
                int userid = rs.getInt("userid");
                String registtime = rs.getString("registtime");
                int visitstate = rs.getInt("visitstate");

                register.setId(id);

                register.setRealname(realname);
                register.setGender(gender);
                register.setIdnumber(idnumber);
                register.setBirthdate(birthdate);
                register.setAge(age);
                register.setAgetype(agetype);
                register.setHomeaddress(homeaddress);
                register.setDeptid(deptid);
                register.setUserid(userid);
                register.setRegisttime(registtime);
                register.setVisitstate(visitstate);

                registers.add(register);
            }
        } catch (SQLException e) {
            e.printStackTrace();

        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return registers;
    }

    //作废
    public boolean cancelRegister(int id){
        String sql = "update tbl_register set visitstate = 0 where id = ?";
        return DBCPUtil.execUpdate(sql,id);
    }

}

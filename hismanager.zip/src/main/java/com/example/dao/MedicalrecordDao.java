package com.example.dao;


import com.example.model.Drugs;
import com.example.model.Medicalrecord;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */
public class MedicalrecordDao {

    /**
     * 添加科室操作
     * @param medicalrecord
     * @return
     */
    public boolean addMedicalrecord(Medicalrecord medicalrecord){
        boolean flag = false;
        String sql ="insert into tbl_medicalrecord(casenumber,registid,presenttreat,history,allergy,proposal,casestate) " +
                "values(?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,medicalrecord.getCasenumber(),medicalrecord.getRegistid(),medicalrecord
                .getPresenttreat(),medicalrecord.getHistory(),medicalrecord.getAllergy(),medicalrecord.getProposal(),medicalrecord.getCasestate());

    }
    public boolean updateMedicalrecord(Medicalrecord medicalrecord){
        boolean flag = false;
        String sql ="update tbl_medicalrecord set casenumber=?,registid=?,presenttreat=?,history=?,allergy=?,proposal=?,casestate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,medicalrecord.getCasenumber(),medicalrecord.getRegistid(),medicalrecord
                .getPresenttreat(),medicalrecord.getHistory(),medicalrecord.getAllergy(),medicalrecord.getProposal(),medicalrecord.getCasestate(),medicalrecord.getId());
        return flag;
    }

    public boolean deleteMedicalrecord(int id){
        boolean flag = false;
        String sql ="delete from tbl_medicalrecord where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;

    }

    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<Medicalrecord> findAll(){
        List<Medicalrecord> medicalrecords = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,casenumber,registid,presenttreat,history,allergy,proposal,casestate from tbl_medicalrecord";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
           Medicalrecord medicalrecord = null;
            while(rs.next()){
                medicalrecord = new Medicalrecord();
                int id= rs.getInt("id");
                String casenumber = rs.getString("casenumber");
                int registid = rs.getInt("registid");
                String presenttreat = rs.getString("presenttreat");
                String history = rs.getString("history");
                String allergy = rs.getString("allergy");
                String proposal = rs.getString("proposal");
                int casestate = rs.getInt("casestate");

                //每行记录封装为一个对象
                medicalrecord.setId(id);
                medicalrecord.setCasenumber(casenumber);
                medicalrecord.setRegistid(registid);
                medicalrecord.setPresenttreat(presenttreat);
                medicalrecord.setHistory(history);
                medicalrecord.setAllergy(allergy);
                medicalrecord.setProposal(proposal);
                medicalrecord.setCasestate(casestate);

                //将对象添加到List集合中
                medicalrecords.add(medicalrecord);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return medicalrecords;
    }
    public Medicalrecord findMedicalrecordByID(int medicalrecordid) {
        Medicalrecord medicalrecord = new Medicalrecord();
        //1.获取数据库连接对象
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,casenumber,registid,presenttreat,history,allergy,proposal,casestate from tbl_medicalrecord where id=?";
            try {
                pstmt = connection.prepareStatement(sql);
                pstmt.setInt(1, medicalrecordid);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String casenumber = rs.getString("casenumber");
                int registid = rs.getInt("registid");
                String presenttreat = rs.getString("presenttreat");
                String history = rs.getString("history");
                String allergy = rs.getString("allergy");
                String proposal = rs.getString("proposal");
                int casestate = rs.getInt("casestate");
                //每行记录封装为一个对象
                medicalrecord.setId(id);
                medicalrecord.setCasenumber(casenumber);
                medicalrecord.setRegistid(registid);
                medicalrecord.setPresenttreat(presenttreat);
                medicalrecord.setHistory(history);
                medicalrecord.setAllergy(allergy);
                medicalrecord.setProposal(proposal);
                medicalrecord.setCasestate(casestate);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }
        return medicalrecord;
    }



}


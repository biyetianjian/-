package com.example.dao;


import com.example.model.Disecategory;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DisecategoryDao {
    /**
     * 添加
     */
    public boolean addDisecategory(Disecategory disecategory){
        boolean flag = false;
        String sql = "insert into tbl_disecategory(dicacode,dicaname,sequenceno,dicatype,delmark,deldate) values " +
                "(?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,disecategory.getDicacode(),disecategory.getDicaname(),disecategory.getSequenceno()
                ,disecategory.getDicatype(),disecategory.getDelmark(),disecategory.getDeldate());


    }

    /**
     * 修改
     */
    public boolean updateDisecategory(Disecategory disecategory){
        boolean flag = false;
        String sql = "update tbl_disecategory set dicacode = ?,dicaname = ?,sequenceno=?,dicatype=?,delmark=? where id = ?";
        flag = DBCPUtil.execUpdate(sql,disecategory.getDicacode(),disecategory.getDicaname(),disecategory.getSequenceno(),
                disecategory.getDicatype(),disecategory.getDelmark(),disecategory.getId());
        return flag;
    }

    /**
     * 删除
     */

    public boolean deleteDisecategory(int id){
        boolean flag = false;
        String sql = "delete from tbl_disecategory where id = ?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    /**
     * 查询id
     */
    public Disecategory findDiesecategoryID(int dcid){
        Disecategory disecategory = new Disecategory();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,dicacode,dicaname,sequenceno,dicatype,delmark,deldate from tbl_disecategory where id=? ";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,dcid);
            rs = pstmt.executeQuery();

            if (rs.next()){

                int id = rs.getInt("id");
                String dicacode = rs.getString("dicacode");
                String dicaname = rs.getString("dicaname");
                int sequenceno = rs.getInt("sequenceno");
                int dicatype = rs.getInt("dicatype");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                disecategory.setId(id);
                disecategory.setDicacode(dicacode);
                disecategory.setDicaname(dicaname);
                disecategory.setSequenceno(sequenceno);
                disecategory.setDicatype(dicatype);
                disecategory.setDelmark(delmark);
                disecategory.setDeldate(deldate);




            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disecategory;

    }


    /**
     * 查询
     */

    public List<Disecategory> findAll(){
        List<Disecategory> disecategories =new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,dicacode,dicaname,sequenceno,dicatype,delmark,deldate from tbl_disecategory where delmark = 1";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Disecategory disecategory = null;
            while (rs.next()){
                disecategory = new Disecategory();
                int id = rs.getInt("id");
                String dicacode = rs.getString("dicacode");
                String dicaname = rs.getString("dicaname");
                int sequenceno = rs.getInt("sequenceno");
                int dicatype = rs.getInt("dicatype");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                disecategory.setId(id);
                disecategory.setDicacode(dicacode);
                disecategory.setDicaname(dicaname);
                disecategory.setSequenceno(sequenceno);
                disecategory.setDicatype(dicatype);
                disecategory.setDelmark(delmark);
                disecategory.setDeldate(deldate);

                disecategories.add(disecategory);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disecategories;
    }

    //作废
    public boolean cancelDisecategory(int id){
        String sql = "update tbl_disecategory set delmark = 0,deldate = now() where id =?";
        return DBCPUtil.execUpdate(sql,id);
    }
}

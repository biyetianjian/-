package com.example.dao;

import com.example.model.User;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    public boolean addUser(User user){
        boolean flag = false;
        String sql ="insert into tbl_user(username,password,realname,usetype,doctitleid,deptid,registleid,delmark) "+
                "values(?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,user.getUsername(),user.getPassword(),user.getRealname(),user.getUsetype(),
                user.getDoctitleid(), user.getDeptid(),user.getRegistleid(),user.getDelmark());

    }

    public boolean updateUser(User user){
        boolean flag = false;
        String sql ="update tbl_user set username=?,password=?,realname=?,usetype=?,doctitleid=?,deptid=?,registleid=?,delmark=? where id=?";
        flag = DBCPUtil.execUpdate(sql,user.getUsername(),user.getPassword(),user.getRealname(),user.getUsetype(),
                user.getDoctitleid(), user.getDeptid(),user.getRegistleid(),user.getDelmark(),user.getId());
        return flag;
    }



    public List<User> findAll(){
        List<User> users = new ArrayList<>();
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,username,password,realname,usetype,doctitleid,deptid,registleid,delmark from tbl_User where delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            User user = null;
            while (rs.next()) {
                user = new User();
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");
                int usetype = rs.getInt("usetype");
                String doctitleid = rs.getString("doctitleid");
                int deptid = rs.getInt("deptid");
                int registleid = rs.getInt("registleid");
                int delmark = rs.getInt("delmark");

                user.setId(id);
                user.setUsername(username);
                user.setPassword(password);
                user.setRealname(realname);
                user.setUsetype(usetype);
                user.setDoctitleid(doctitleid);
                user.setDeptid(deptid);
                user.setRegistleid(registleid);
                user.setDelmark(delmark);

                users.add(user);

            }
            }   catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBCPUtil.release(connection,pstmt,rs);
            }
            return users;

        }

    public boolean deleteUser(int id){
     boolean flag = false;
     String sql ="delete from tbl_User where id =? ";
     flag = DBCPUtil.execUpdate(sql,id);
     return flag;
    }

    public boolean cancelUser(int id){
        String sql = "update tbl_user set delmark=0,deldate=now() where id=?";
        return DBCPUtil.execUpdate(sql,id);
    }

    public User findUserID(int sssid){
        User user = new User();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,username,password,realname,usetype,doctitleid,deptid,registleid,delmark from tbl_user where id=? and delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,sssid);

            rs = pstmt.executeQuery();

            if (rs.next()) {

                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");
                int usetype = rs.getInt("usetype");
                String doctitleid = rs.getString("doctitleid");
                int deptid = rs.getInt("deptid");
                int registleid = rs.getInt("registleid");
                int delmark = rs.getInt("delmark");

                user.setId(id);
                user.setUsername(username);
                user.setPassword(password);
                user.setRealname(realname);
                user.setUsetype(usetype);
                user.setDoctitleid(doctitleid);
                user.setDeptid(deptid);
                user.setRegistleid(registleid);
                user.setDelmark(delmark);


            }
        }   catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return user;

    }

}

package com.example.dao;

import com.example.model.Disease;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DiseaseDao {

    //添加
    public boolean addDisease(Disease disease){
        boolean flag = false;
        String sql = "insert into tbl_disease(diseasecode,diseasename,diseaseicd,disecategoryid,delmark) " +
                "values(?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,disease.getDiseasecode(),disease.getDiseasename(),
                disease.getDiseaseicd(),disease.getDisecategoryid(),disease.getDelmark());
    }


    //修改
    public boolean updateDisease(Disease disease){
        boolean flag = false;
        String sql = "update tbl_disease set diseasecode=?,diseasename=?,diseaseicd=?,disecategoryid=? where id=?";
        flag = DBCPUtil.execUpdate(sql,disease.getDiseasecode(),disease.getDiseasename(),
                disease.getDiseaseicd(), disease.getDisecategoryid(),disease.getId());
        return flag;
    }

    //删除
    public boolean deleteDisease(int id){
        boolean flag = false;
        String sql = "delete from tbl_disease where id=?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    //查找
    public List<Disease> findAll(){
        List<Disease> diseases = new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        String sql = "select id,diseasecode,diseasename,diseaseicd,disecategoryid,delmark,deldate,deldate from tbl_disease where delmark = 1";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Disease disease = null;
            while (rs.next()) {
                disease = new Disease();
                int id = rs.getInt("id");
                String diseasecode = rs.getString("diseasecode");
                String diseasename = rs.getString("diseasename");
                String diseaseicd = rs.getString("diseaseicd");
                int disecategoryid = rs.getInt("disecategoryid");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                disease.setId(id);
                disease.setDiseasecode(diseasecode);
                disease.setDiseasename(diseasename);
                disease.setDiseaseicd(diseaseicd);
                disease.setDisecategoryid(disecategoryid);
                disease.setDelmark(delmark);
                disease.setDeldate(deldate);

                diseases.add(disease);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return diseases;
    }
    //查询id
    public Disease findDiseaseID(int dsid){
        Disease disease = new Disease();


        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        String sql = "select id,diseasecode,diseasename,diseaseicd,disecategoryid,delmark,deldate,deldate from tbl_disease where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,dsid);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String diseasecode = rs.getString("diseasecode");
                String diseasename = rs.getString("diseasename");
                String diseaseicd = rs.getString("diseaseicd");
                int disecategoryid = rs.getInt("disecategoryid");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                disease.setId(id);
                disease.setDiseasecode(diseasecode);
                disease.setDiseasename(diseasename);
                disease.setDiseaseicd(diseaseicd);
                disease.setDisecategoryid(disecategoryid);
                disease.setDelmark(delmark);
                disease.setDeldate(deldate);


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disease;
    }
    //作废
    public boolean cancelDisease(int id){
        String sql = "update tbl_disease set delmark = 0,deldate=now() where id =?";
        return DBCPUtil.execUpdate(sql,id);
    }

}

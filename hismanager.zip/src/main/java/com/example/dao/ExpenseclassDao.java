package com.example.dao;

import com.example.model.Expenseclass;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ExpenseclassDao {

    //添加
    public boolean addExpenseclass(Expenseclass expenseclass){
        boolean flag = false;
        String sql = "insert into tbl_expenseclass(expcode,expname) " +
                "values(?,?)";
        return DBCPUtil.execUpdate(sql,expenseclass.getExpcode(),expenseclass.getExpname());
    }


    //修改
    public boolean updateExpenseclass(Expenseclass expenseclass){
        boolean flag = false;
        String sql = "update tbl_expenseclass set expcode=?,expname=? where id=?";
        flag = DBCPUtil.execUpdate(sql,expenseclass.getExpcode(),expenseclass.getExpname(),expenseclass.getId());
        return flag;
    }

    //删除
    public boolean deleteExpenseclass(int id){
        boolean flag = false;
        String sql = "delete from tbl_expenseclass where id=?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    //查找
    public List<Expenseclass> findAll(){
        List<Expenseclass> expenseclasss = new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        String sql = "select id,expcode,expname from tbl_expenseclass";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Expenseclass expenseclass = null;
            while (rs.next()) {
                expenseclass = new Expenseclass();
                int id = rs.getInt("id");
                String expcode = rs.getString("expcode");
                String expname = rs.getString("expname");


                expenseclass.setId(id);
                expenseclass.setExpcode(expcode);
                expenseclass.setExpname(expname);

                expenseclasss.add(expenseclass);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return expenseclasss;
    }
    public Expenseclass findExpenseclassByID(int expenid){
        Expenseclass expenseclass = new Expenseclass();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        String sql = "select id,expcode,expname from tbl_expenseclass where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,expenid);

            rs = pstmt.executeQuery();
            if(rs.next()) {

                int id = rs.getInt("id");
                String expcode = rs.getString("expcode");
                String expname = rs.getString("expname");


                expenseclass.setId(id);
                expenseclass.setExpcode(expcode);
                expenseclass.setExpname(expname);


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return expenseclass;
    }


}

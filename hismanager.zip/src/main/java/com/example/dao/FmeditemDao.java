package com.example.dao;
import com.example.model.Expenseclass;
import com.example.model.Fmeditem;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FmeditemDao {
    /**
     * 添加
     */
    public boolean addFmeditem(Fmeditem fmeditem){
        boolean flag = false;
        String sql = "insert into tbl_fmeditem (itemcode,itemname,expclassid,deptid,mnemoniccode,creationdate," +
                "lastupdatedate,recordtype,delmark,deldate) values (?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,fmeditem.getItemcode(),fmeditem.getItemname(),fmeditem.getExpclassid(),fmeditem.getDeptid(),
                fmeditem.getMnemoniccode(),fmeditem.getCreationdate(),fmeditem.getLastupdatedate(), fmeditem.getRecordtype(),
                fmeditem.getDelmark(),fmeditem.getDeldate());



    }

    /**
     * 修改
     */
    public boolean updateFmeditem(Fmeditem fmeditem){
        boolean flag = false;
        String sql = "update tbl_fmeditem set itemcode=?,itemname=?,expclassid=?,deptid=?,mnemoniccode=?,creationdate=?," +
                "lastupdatedate=?,recordtype=?,delmark=?,deldate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,fmeditem.getItemcode(),fmeditem.getItemname(),fmeditem.getExpclassid(),
                fmeditem.getDeptid(),fmeditem.getMnemoniccode(),fmeditem.getCreationdate(),
                fmeditem.getLastupdatedate(),fmeditem.getRecordtype(),fmeditem.getDelmark(),fmeditem.getDeldate(),fmeditem.getId());
        return flag;
    }


    /**
     * 删除
     */
    public boolean deleteFmeditem(int id){
        boolean flag = false;
        String sql = "delete from tbl_fmeditem where id = ?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;


    }
    /**
     * 功能：作废操作
     * @param id
     * @return
     */
    public boolean cancelFmeditem(int id){
        String sql = "update tbl_fmeditem set delmark=0,deldate=now() where id=? ";
        return DBCPUtil.execUpdate(sql,id);
    }

    /**
     * 查询
     */
    public List<Fmeditem> findAll(){
        List<Fmeditem> fmeditems = new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,itemcode,itemname,expclassid,deptid,mnemoniccode,creationdate,lastupdatedate," +
                "recordtype,delmark,deldate from tbl_fmeditem where delmark= 1";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Fmeditem fmeditem = null;
            while (rs.next()){
                fmeditem= new Fmeditem();
                int id = rs.getInt("id");
                String itemcode = rs.getString("itemcode");
                String itemname = rs.getString("itemname");
                int expclassid = rs.getInt("expclassid");
                int deptid = rs.getInt("deptid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int recordtype = rs.getInt("recordtype");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                fmeditem.setId(id);
                fmeditem.setItemcode(itemcode);
                fmeditem.setItemname(itemname);
                fmeditem.setExpclassid(expclassid);
                fmeditem.setDeptid(deptid);
                fmeditem.setMnemoniccode(mnemoniccode);
                fmeditem.setCreationdate(creationdate);
                fmeditem.setLastupdatedate(lastupdatedate);
                fmeditem.setRecordtype(recordtype);
                fmeditem.setDelmark(delmark);
                fmeditem.setDeldate(deldate);

                fmeditems.add(fmeditem);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }return fmeditems;
    }
    public Fmeditem findFmeditemByID(int fmedid){
        Fmeditem fmeditem = new Fmeditem();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,itemcode,itemname,expclassid,deptid,mnemoniccode,creationdate,lastupdatedate," +
                "recordtype,delmark,deldate from tbl_fmeditem where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,fmedid);
            rs = pstmt.executeQuery();
            if(rs.next()){
                int id = rs.getInt("id");
                String itemcode = rs.getString("itemcode");
                String itemname = rs.getString("itemname");
                int expclassid = rs.getInt("expclassid");
                int deptid = rs.getInt("deptid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int recordtype = rs.getInt("recordtype");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                fmeditem.setId(id);
                fmeditem.setItemcode(itemcode);
                fmeditem.setItemname(itemname);
                fmeditem.setExpclassid(expclassid);
                fmeditem.setDeptid(deptid);
                fmeditem.setMnemoniccode(mnemoniccode);
                fmeditem.setCreationdate(creationdate);
                fmeditem.setLastupdatedate(lastupdatedate);
                fmeditem.setRecordtype(recordtype);
                fmeditem.setDelmark(delmark);
                fmeditem.setDeldate(deldate);


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return fmeditem;
    }

}

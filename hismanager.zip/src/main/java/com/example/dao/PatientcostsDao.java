package com.example.dao;

import com.example.model.Patientcosts;

import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientcostsDao {
    public boolean addPatientcosts(Patientcosts patientcosts){
        boolean flag = false;
        String sql = "insert into tbl_patientcosts (registid,itemid,itemtype,name,unitprice,amount,registerid,createoperid,feetype,retmark,retdate) " +
                "values (?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,patientcosts.getRegistid(),patientcosts.getItemid(),patientcosts.getItemtype(),
                patientcosts.getName(),patientcosts.getUnitprice(), patientcosts.getAmount(),patientcosts.getRegisterid(),patientcosts.getCreateoperid()
               ,patientcosts.getFeetype(),patientcosts.getRetmark(),patientcosts.getRetdate());

    }

    /**
     * 功能：作废操作
     * @param id
     * @return
     */
    public boolean cancelPatientcosts(int id){
        String sql = "update tbl_patientcosts set retmark=0,retdate=now() where id=? ";
        return DBCPUtil.execUpdate(sql,id);
    }



    /**
     * 查询
     */
    public List<Patientcosts> findALL(){
        List<Patientcosts> patientcostss = new ArrayList<>();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,registid,itemid,itemtype,name,unitprice,amount,registerid,createoperid,feetype,retmark,retdate from tbl_patientcosts";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Patientcosts patientcosts = null;
            while (rs.next()){
                patientcosts = new Patientcosts();
                int id = rs.getInt("id");
                int registid=rs.getInt("registid");
                int itemid = rs.getInt("itemid");
                int itemtype = rs.getInt("itemtype");
                String name = rs.getString("name");
                int unitprice = rs.getInt("unitprice");
                int amount = rs.getInt("amount");
                int registerid = rs.getInt("registerid");
                int createoperid = rs.getInt("createoperid");





                int feetype = rs.getInt("feetype");
                int retmark = rs.getInt("retmark");
                String retdate = rs.getString("retdate");

                patientcosts.setId(id);
                patientcosts.setRegistid(registid);
                patientcosts.setItemid(itemid);
                patientcosts.setItemtype(itemtype);
                patientcosts.setName(name);
                patientcosts.setUnitprice(unitprice);
                patientcosts.setAmount(amount);
                patientcosts.setRegisterid(registerid);
                patientcosts.setCreateoperid(createoperid);


                patientcosts.setFeetype(feetype);
                patientcosts.setRetmark(retmark);
                patientcosts.setRetdate(retdate);

                patientcostss.add(patientcosts);


            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);

        }
        return patientcostss;
    }

    public Patientcosts findPatientcostsByID(int patid){
        Patientcosts patientcosts = new Patientcosts();
    //1.获取数据库连接对象
    Connection connection =  DBCPUtil.getConnection();
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    String sql ="select id,registid,itemid,itemtype,name,unitprice,amount,registerid,createoperid,feetype,retmark,retdate from tbl_patientcosts where id=?";
    try {
        pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1,patid);

        rs = pstmt.executeQuery();

        if(rs.next()){
            int id= rs.getInt("id");
            int registid=rs.getInt("registid");

            int itemid = rs.getInt("itemid");
            int itemtype = rs.getInt("itemtype");
            String name = rs.getString("name");
            int unitprice = rs.getInt("unitprice");
            int amount = rs.getInt("amount");
            int registerid = rs.getInt("registerid");
            int createoperid = rs.getInt("createoperid");


            int feetype = rs.getInt("feetype");
            int retmark = rs.getInt("retmark");
            String retdate = rs.getString("retdate");
            //每行记录封装为一个对象
            patientcosts.setId(id);
            patientcosts.setRegistid(registid);
            patientcosts.setItemid(itemid);
            patientcosts.setItemtype(itemtype);
            patientcosts.setName(name);
            patientcosts.setUnitprice(unitprice);
            patientcosts.setAmount(amount);
            patientcosts.setRegisterid(registerid);
            patientcosts.setCreateoperid(createoperid);
            patientcosts.setFeetype(feetype);
            patientcosts.setRetmark(retmark);
            patientcosts.setRetdate(retdate);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        DBCPUtil.release(connection,pstmt,rs);
    }
    return patientcosts;
}
}

package com.example.dao;

import com.example.model.Drugs;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DrugsDao {
    public boolean addDrugs(Drugs drugs){
        boolean flag = false;
        String sql ="insert into tbl_drugs(drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsprice,drugstypeid,mnemoniccode,creationdate) "+
                "values(?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,drugs.getDrugscode(),drugs.getDrugsname(),drugs.getDrugsformat(),drugs.getDrugsunit(),
                drugs.getManufacturer(), drugs.getDrugsprice(),drugs.getDrugstypeid(),drugs.getMnemoniccode(),drugs.getCreationdate());

    }

    public boolean updateDrugs(Drugs drugs){
        boolean flag = false;
        String sql ="update tbl_drugs set drugscode=?,drugsname=?,drugsformat=?,drugsunit=?,manufacturer=?,drugsprice=?,drugstypeid=?,mnemoniccode=?,creationdate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,drugs.getDrugscode(),drugs.getDrugsname(),drugs.getDrugsformat(),drugs.getDrugsunit(),
                drugs.getManufacturer(), drugs.getDrugsprice(),drugs.getDrugstypeid(),drugs.getMnemoniccode(),drugs.getCreationdate(),drugs.getId());
        return flag;
    }

    public boolean deleteDrugs(int id){
        boolean flag = false;
        String sql ="delete from tbl_drugs where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;

    }

    public List<Drugs> findAll(){
        List<Drugs> drugss = new ArrayList<>();
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsprice,drugstypeid,mnemoniccode,creationdate from tbl_drugs";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Drugs drugs = null;
            while (rs.next()) {
                drugs = new Drugs();
                int id = rs.getInt("id");
                String drugscode = rs.getString("drugscode");
                String drugsname = rs.getString("drugsname");
                String drugsformat = rs.getString("drugsformat");
                String drugsunit = rs.getString("drugsunit");
                String manufacturer = rs.getString("manufacturer");
                int drugsprice = rs.getInt("drugsprice");
                int drugstypeid = rs.getInt("drugstypeid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");


                drugs.setId(id);
                drugs.setDrugscode(drugscode);
                drugs.setDrugsname(drugsname);
                drugs.setDrugsformat(drugsformat);
                drugs.setDrugsunit(drugsunit);
                drugs.setManufacturer(manufacturer);
                drugs.setDrugsprice(drugsprice);
                drugs.setDrugstypeid(drugstypeid);
                drugs.setMnemoniccode(mnemoniccode);
                drugs.setCreationdate(creationdate);

                drugss.add(drugs);

            }
        }   catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return drugss;

    }
    /**
     * 功能：根据主键查询科室信息
     * @param drugsid
     * @return
     */
    public Drugs findDrugsByID(int drugsid){
        Drugs drugs = new Drugs();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsprice,drugstypeid,mnemoniccode,creationdate from tbl_drugs where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,drugsid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id = rs.getInt("id");
                String drugscode = rs.getString("drugscode");
                String drugsname = rs.getString("drugsname");
                String drugsformat = rs.getString("drugsformat");
                String drugsunit = rs.getString("drugsunit");
                String manufacturer = rs.getString("manufacturer");
                int drugsprice = rs.getInt("drugsprice");
                int drugstypeid = rs.getInt("drugstypeid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");

                //每行记录封装为一个对象
                drugs.setId(id);
                drugs.setDrugscode(drugscode);
                drugs.setDrugsname(drugsname);
                drugs.setDrugsformat(drugsformat);
                drugs.setDrugsunit(drugsunit);
                drugs.setManufacturer(manufacturer);
                drugs.setDrugsprice(drugsprice);
                drugs.setDrugstypeid(drugstypeid);
                drugs.setMnemoniccode(mnemoniccode);
                drugs.setCreationdate(creationdate);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return drugs;
    }
}

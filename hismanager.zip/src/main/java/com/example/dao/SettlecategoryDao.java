package com.example.dao;

import com.example.model.Settlecategory;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SettlecategoryDao {

    public boolean addSettlecategory(Settlecategory settlecategory){
        boolean flag = false;
        String sql = "insert into tbl_settlecategory(registcode,registname,sequenceno,delmark,deldate) " +
                "values(?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,settlecategory.getRegistcode(),settlecategory.getRegistname(),
                settlecategory.getSequenceno(),settlecategory.getDelmark(),settlecategory.getDeldate());
    }


    public boolean updateSettlecategory(Settlecategory settlecategory){
        boolean flag = false;
        String sql = "update tbl_settlecategory set registcode=?,registname=?,sequenceno=?,deldate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,settlecategory.getRegistcode(),settlecategory.getRegistname(),
                settlecategory.getSequenceno(),settlecategory.getDeldate(),settlecategory.getId());
        return flag;
    }


    public List<Settlecategory> findAll(){
        List<Settlecategory> settlecategorys = new ArrayList<>();
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt =null;
        ResultSet rs = null;
        String sql = "select id,registcode,registname,sequenceno,delmark,deldate from tbl_settlecategory where delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Settlecategory settlecategory = null;
            while (rs.next()) {
                settlecategory = new Settlecategory();
                int id = rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                settlecategory.setId(id);
                settlecategory.setRegistcode(registcode);
                settlecategory.setRegistname(registname);
                settlecategory.setSequenceno(sequenceno);
                settlecategory.setDelmark(delmark);
                settlecategory.setDeldate(deldate);

                settlecategorys.add(settlecategory);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return settlecategorys;
    }

    public boolean deleteSettlecategory(int id){
        boolean flag = false;
        String sql = "delete from tbl_settlecategory where id=?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    public boolean cancelSettlecategory(int id){
        String sql = "update tbl_settlecategory set delmark=0,deldate=now() where id=?";
        return DBCPUtil.execUpdate(sql,id);
    }

    public Settlecategory findSettlecategoryID(int sssid){
        Settlecategory settlecategory = new Settlecategory();

        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registcode,registname,sequenceno,delmark,deldate from tbl_settlecategory where id=? and delmark='1'";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,sssid);

            rs = pstmt.executeQuery();

            if (rs.next()) {

                int id = rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                int delmark = rs.getInt("delmark");
                String deldate = rs.getString("deldate");

                settlecategory.setId(id);
                settlecategory.setRegistname(registname);
                settlecategory.setRegistcode(registcode);
                settlecategory.setSequenceno(sequenceno);
                settlecategory.setDelmark(delmark);
                settlecategory.setDeldate(deldate);


            }
        }   catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return settlecategory;

    }
}

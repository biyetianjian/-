package com.example.model;

/**
 * 实体类--科室
 */
public class Checkapply {
    //id, deptcode,deptname,  depttype
    private Integer id;
    private Integer itemid;
    private String name;
    private String objective;
    private String position;
    private Integer isurgent;
    private Integer num;
    private String creationtime;
    private Integer checkoperid;
    private Integer resultoperid;
    private Integer state;
    private String checkresult;
    private String remark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Integer getIsurgent() {
        return isurgent;
    }

    public void setIsurgent(Integer isurgent) {
        this.isurgent = isurgent;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(String creationtime) {
        this.creationtime = creationtime;
    }

    public Integer getCheckoperid() {
        return checkoperid;
    }

    public void setCheckoperid(Integer checkoperid) {
        this.checkoperid = checkoperid;
    }

    public Integer getResultoperid() {
        return resultoperid;
    }

    public void setResultoperid(Integer resultoperid) {
        this.resultoperid = resultoperid;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getCheckresult() {
        return checkresult;
    }

    public void setCheckresult(String checkresult) {
        this.checkresult = checkresult;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "Checkapply{" +
                "id=" + id +
                ", itemid=" + itemid +
                ", name='" + name + '\'' +
                ", objective='" + objective + '\'' +
                ", position='" + position + '\'' +
                ", isurgent=" + isurgent +
                ", num=" + num +
                ", creationtime='" + creationtime + '\'' +
                ", checkoperid=" + checkoperid +
                ", resultoperid=" + resultoperid +
                ", state=" + state +
                ", checkresult='" + checkresult + '\'' +
                ", remark='" + remark + '\'' +
                '}';
    }
}

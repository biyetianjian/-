package com.example.model;

public class Prescription {
    private Integer id;
    private Integer medicalid;
    private Integer registlid;
    private Integer userid;
    private String prescriptionname;
    private String prescriptiontime;
    private Integer prescriptionstate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMedicalid() {
        return medicalid;
    }

    public void setMedicalid(Integer medicalid) {
        this.medicalid = medicalid;
    }

    public Integer getRegistlid() {
        return registlid;
    }

    public void setRegistlid(Integer registlid) {
        this.registlid = registlid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getPrescriptionname() {
        return prescriptionname;
    }

    public void setPrescriptionname(String prescriptionname) {
        this.prescriptionname = prescriptionname;
    }

    public String getPrescriptiontime() {
        return prescriptiontime;
    }

    public void setPrescriptiontime(String prescriptiontime) {
        this.prescriptiontime = prescriptiontime;
    }

    public Integer getPrescriptionstate() {
        return prescriptionstate;
    }

    public void setPrescriptionstate(Integer prescriptionstate) {
        this.prescriptionstate = prescriptionstate;
    }

    @Override
    public String toString() {
        return "Prescription{" +
                "id=" + id +
                ", medicalid=" + medicalid +
                ", registlid=" + registlid +
                ", userid=" + userid +
                ", prescriptionname='" + prescriptionname + '\'' +
                ", prescriptiontime='" + prescriptiontime + '\'' +
                ", prescriptionstate=" + prescriptionstate +
                '}';
    }
}
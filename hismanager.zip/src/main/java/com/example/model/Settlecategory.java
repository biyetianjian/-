package com.example.model;

public class Settlecategory {

    private Integer id;
    private String registcode;
    private String registname;
    private Integer sequenceno;
    private Integer delmark;
    private String deldate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegistcode() {
        return registcode;
    }

    public void setRegistcode(String registcode) {
        this.registcode = registcode;
    }

    public String getRegistname() {
        return registname;
    }

    public void setRegistname(String registname) {
        this.registname = registname;
    }

    public Integer getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(Integer sequenceno) {
        this.sequenceno = sequenceno;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public String getDeldate() {
        return deldate;
    }

    public void setDeldate(String deldate) {
        this.deldate = deldate;
    }

    @Override
    public String toString() {
        return "Settlecategory{" +
                "id=" + id +
                ", registcode='" + registcode + '\'' +
                ", registname='" + registname + '\'' +
                ", sequenceno=" + sequenceno +
                ", delmark=" + delmark +
                ", deldate='" + deldate + '\'' +
                '}';
    }
}

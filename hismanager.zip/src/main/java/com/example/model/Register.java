package com.example.model;

public class Register {
    private Integer id;

    private String realname;
    private String gender;
    private String idnumber;
    private String birthdate;
    private Integer age;
    private String agetype;
    private String homeaddress;
    private Integer deptid;
    private Integer userid;
    private String registtime;
    private Integer visitstate;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }




    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getAgetype() {
        return agetype;
    }

    public void setAgetype(String agetype) {
        this.agetype = agetype;
    }

    public String getHomeaddress() {
        return homeaddress;
    }

    public void setHomeaddress(String homeaddress) {
        this.homeaddress = homeaddress;
    }

    public Integer getDeptid() {
        return deptid;
    }

    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public String getRegisttime() {
        return registtime;
    }

    public void setRegisttime(String registtime) {
        this.registtime = registtime;
    }

    public Integer getVisitstate() {
        return visitstate;
    }

    public void setVisitstate(Integer visitstate) {
        this.visitstate = visitstate;
    }

    @Override
    public String toString() {
        return "Register{" +
                "id=" + id +
                ", realname='" + realname + '\'' +
                ", gender='" + gender + '\'' +
                ", idnumber='" + idnumber + '\'' +
                ", birthdate='" + birthdate + '\'' +
                ", age=" + age +
                ", agetype='" + agetype + '\'' +
                ", homeaddress='" + homeaddress + '\'' +
                ", deptid=" + deptid +
                ", userid=" + userid +
                ", registtime='" + registtime + '\'' +
                ", visitstate=" + visitstate +
                '}';
    }
}

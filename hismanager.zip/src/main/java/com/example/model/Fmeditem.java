package com.example.model;

public class Fmeditem {
    private Integer id;
    private String itemcode;
    private String itemname;
    private Integer expclassid;
    private Integer deptid;
    private String mnemoniccode;
    private String creationdate;
    private String lastupdatedate;
    private Integer recordtype;
    private Integer delmark;
    private String deldate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemcode() {
        return itemcode;
    }

    public void setItemcode(String itemcode) {
        this.itemcode = itemcode;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getExpclassid() {
        return expclassid;
    }

    public void setExpclassid(Integer expclassid) {
        this.expclassid = expclassid;
    }

    public Integer getDeptid() {
        return deptid;
    }

    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    public String getMnemoniccode() {
        return mnemoniccode;
    }

    public void setMnemoniccode(String mnemoniccode) {
        this.mnemoniccode = mnemoniccode;
    }

    public String getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(String creationdate) {
        this.creationdate = creationdate;
    }

    public String getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(String lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public Integer getRecordtype() {
        return recordtype;
    }

    public void setRecordtype(Integer recordtype) {
        this.recordtype = recordtype;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public String getDeldate() {
        return deldate;
    }

    public void setDeldate(String deldate) {
        this.deldate = deldate;
    }

    @Override
    public String toString() {
        return "Fmeditem{" +
                "id=" + id +
                ", itemcode='" + itemcode + '\'' +
                ", itemname='" + itemname + '\'' +
                ", expcalssid=" + expclassid +
                ", deptid=" + deptid +
                ", mnemoniccode='" + mnemoniccode + '\'' +
                ", creationdate='" + creationdate + '\'' +
                ", lastupdatedate='" + lastupdatedate + '\'' +
                ", recordtype=" + recordtype +
                ", delmark=" + delmark +
                ", deldate='" + deldate + '\'' +
                '}';
    }
}

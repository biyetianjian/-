package com.example.model;

public class Disecategory {
    private Integer id;
    private String dicacode;
    private String dicaname;
    private Integer sequenceno;
    private Integer dicatype;
    private Integer delmark;
    private String deldate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDicacode() {
        return dicacode;
    }

    public void setDicacode(String dicacode) {
        this.dicacode = dicacode;
    }

    public String getDicaname() {
        return dicaname;
    }

    public void setDicaname(String dicaname) {
        this.dicaname = dicaname;
    }

    public Integer getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(Integer sequenceno) {
        this.sequenceno = sequenceno;
    }

    public Integer getDicatype() {
        return dicatype;
    }

    public void setDicatype(Integer dicatype) {
        this.dicatype = dicatype;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public String getDeldate() {
        return deldate;
    }

    public void setDeldate(String deldate) {
        this.deldate = deldate;
    }

    @Override
    public String toString() {
        return "Disecategory{" +
                "id=" + id +
                ", dicacode='" + dicacode + '\'' +
                ", dicaname='" + dicaname + '\'' +
                ", sequenceno=" + sequenceno +
                ", dicatype=" + dicatype +
                ", delmark=" + delmark +
                ", deldate='" + deldate + '\'' +
                '}';
    }
}

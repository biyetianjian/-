package com.example.model;

/**
 * 实体类--科室
 */
public class Medicalrecord {

    private Integer id;
    private String casenumber;
    private Integer registid;
    private String presenttreat;
    private String history;
    private String allergy;
    private String proposal;
    private Integer casestate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCasenumber() {
        return casenumber;
    }

    public void setCasenumber(String casenumber) {
        this.casenumber = casenumber;
    }

    public Integer getRegistid() {
        return registid;
    }

    public void setRegistid(Integer registid) {
        this.registid = registid;
    }

    public String getPresenttreat() {
        return presenttreat;
    }

    public void setPresenttreat(String presenttreat) {
        this.presenttreat = presenttreat;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getAllergy() {
        return allergy;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public String getProposal() {
        return proposal;
    }

    public void setProposal(String proposal) {
        this.proposal = proposal;
    }

    public Integer getCasestate() {
        return casestate;
    }

    public void setCasestate(Integer casestate) {
        this.casestate = casestate;
    }

    @Override
    public String toString() {
        return "Medicalrecord{" +
                "id=" + id +
                ", casenumber='" + casenumber + '\'' +
                ", registid=" + registid +
                ", presenttreat='" + presenttreat + '\'' +
                ", history='" + history + '\'' +
                ", allergy='" + allergy + '\'' +
                ", proposal='" + proposal + '\'' +
                ", casestate=" + casestate +
                '}';
    }
}

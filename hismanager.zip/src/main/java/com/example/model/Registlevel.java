package com.example.model;

public class Registlevel {

    private Integer id;
    private String registcode;
    private String registname;
    private Integer sequenceno;
    private String registfee;
    private Integer registquota;
    private Integer delmark;
    private String deldate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegistcode() {
        return registcode;
    }

    public void setRegistcode(String registcode) {
        this.registcode = registcode;
    }

    public String getRegistname() {
        return registname;
    }

    public void setRegistname(String registname) {
        this.registname = registname;
    }

    public Integer getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(Integer sequenceno) {
        this.sequenceno = sequenceno;
    }

    public String getRegistfee() {
        return registfee;
    }

    public void setRegistfee(String registfee) {
        this.registfee = registfee;
    }

    public Integer getRegistquota() {
        return registquota;
    }

    public void setRegistquota(Integer registquota) {
        this.registquota = registquota;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public String getDeldate() {
        return deldate;
    }

    public void setDeldate(String deldate) {
        this.deldate = deldate;
    }

    @Override
    public String toString() {
        return "Registlevel{" +
                "id=" + id +
                ", registcode='" + registcode + '\'' +
                ", registname='" + registname + '\'' +
                ", sequenceno=" + sequenceno +
                ", registfee='" + registfee + '\'' +
                ", registquota=" + registquota +
                ", delmark=" + delmark +
                ", deldate='" + deldate + '\'' +
                '}';
    }
}


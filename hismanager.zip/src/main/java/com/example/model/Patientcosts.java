package com.example.model;

public class Patientcosts {
    private Integer id;
    private Integer registid;
    private Integer itemid;
    private Integer itemtype;
    private String name;
    private Integer unitprice;
    private Integer amount;
    private Integer registerid;
    private Integer createoperid;
    private Integer feetype;
    private Integer retmark;
    private String retdate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRegistid() {
        return registid;
    }

    public void setRegistid(Integer registid) {
        this.registid = registid;
    }

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getItemtype() {
        return itemtype;
    }

    public void setItemtype(Integer itemtype) {
        this.itemtype = itemtype;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(Integer unitprice) {
        this.unitprice = unitprice;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getRegisterid() {
        return registerid;
    }

    public void setRegisterid(Integer registerid) {
        this.registerid = registerid;
    }

    public Integer getCreateoperid() {
        return createoperid;
    }

    public void setCreateoperid(Integer createoperid) {
        this.createoperid = createoperid;
    }

    public Integer getFeetype() {
        return feetype;
    }

    public void setFeetype(Integer feetype) {
        this.feetype = feetype;
    }

    public Integer getRetmark() {
        return retmark;
    }

    public void setRetmark(Integer retmark) {
        this.retmark = retmark;
    }

    public String getRetdate() {
        return retdate;
    }

    public void setRetdate(String retdate) {
        this.retdate = retdate;
    }

    @Override
    public String toString() {
        return "Patientcosts{" +
                "id=" + id +
                ", registid=" + registid +
                ", itemid=" + itemid +
                ", itemtype=" + itemtype +
                ", name='" + name + '\'' +
                ", unitprice=" + unitprice +
                ", amount=" + amount +
                ", registerid=" + registerid +
                ", createoperid=" + createoperid +
                ", feetype=" + feetype +
                ", retmark=" + retmark +
                ", retdate='" + retdate + '\'' +
                '}';
    }
}



package com.example.model;

public class Disease {
    private Integer id;
    private String diseasecode;
    private String diseasename;
    private String diseaseicd;
    private Integer disecategoryid;
    private Integer delmark;
    private String deldate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDiseasecode() {
        return diseasecode;
    }

    public void setDiseasecode(String diseasecode) {
        this.diseasecode = diseasecode;
    }

    public String getDiseasename() {
        return diseasename;
    }

    public void setDiseasename(String diseasename) {
        this.diseasename = diseasename;
    }

    public String getDiseaseicd() {
        return diseaseicd;
    }

    public void setDiseaseicd(String diseaseicd) {
        this.diseaseicd = diseaseicd;
    }

    public Integer getDisecategoryid() {
        return disecategoryid;
    }

    public void setDisecategoryid(Integer disecategoryid) {
        this.disecategoryid = disecategoryid;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public String getDeldate() {
        return deldate;
    }

    public void setDeldate(String deldate) {
        this.deldate = deldate;
    }

    @Override
    public String toString() {
        return "Disease{" +
                "id=" + id +
                ", diseasecode='" + diseasecode + '\'' +
                ", diseasename='" + diseasename + '\'' +
                ", diseaseicd='" + diseaseicd + '\'' +
                ", disecategoryid=" + disecategoryid +
                ", delmark=" + delmark +
                ", deldate='" + deldate + '\'' +
                '}';
    }
}

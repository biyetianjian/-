package com.example.model;

public class Department {
    private Integer id;
    private String deptcode;
    private String deptname;
    private Integer depttype;
    private Integer deptcategoryid;
    private Integer delmark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public Integer getDepttype() {
        return depttype;
    }

    public void setDepttype(Integer depttype) {
        this.depttype = depttype;
    }

    public Integer getDeptcategoryid() {
        return deptcategoryid;
    }

    public void setDeptcategoryid(Integer deptcategoryid) {
        this.deptcategoryid = deptcategoryid;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", deptcode='" + deptcode + '\'' +
                ", deptname='" + deptname + '\'' +
                ", depttype=" + depttype +
                ", deptcategoryid=" + deptcategoryid +
                ", delmark=" + delmark +
                '}';
    }
}

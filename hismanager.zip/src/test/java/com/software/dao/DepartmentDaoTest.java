package com.software.dao;

import com.example.dao.DepartmentDao;
import com.example.model.Department;
import com.example.model.User;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DepartmentDaoTest {

    DepartmentDao departmentDao = new DepartmentDao();

    @Test
    public void addMethod1(){

        Department department = new Department();
        department.setDeptcode("SJ1002");
        department.setDeptname("神经科2");
        department.setDeptcategoryid(1);
        department.setDepttype(1);
        department.setDelmark(1);

        boolean flag = departmentDao.addDepartment(department);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void updateDepartment(){

        Department department = new Department();
        department.setId(14);
        department.setDeptcode("FS1002");
        department.setDeptname("放射科2");
        department.setDeptcategoryid(1);
        department.setDepttype(1);
        department.setDelmark(1);

        boolean flag = departmentDao.updateDepartment(department);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void deleteMethod(){
        boolean flag = departmentDao.deleteDepartment(14);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryDepartment(){
        List<Department> departmentList =  departmentDao.findAll();
        for(Department department : departmentList){
            System.out.println(department);
        }
    }

    @Test
    public void queryDepartById(){
        Department department =departmentDao.findDeparmtnByID(18);
        System.out.println(department);
    }
    @Test
    public void canceluser(){
        Department department =departmentDao.findDeparmtnByID(18);
        System.out.println(department);
    }

}

package com.software.dao;

import com.example.dao.DisecategoryDao;
import com.example.model.Disecategory;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DisecategoryDaoTest {


    DisecategoryDao disecategoryDao = new DisecategoryDao();

    /**
     * 添加
     */
    @Test
    public void addMethod(){
        Disecategory disecategory = new Disecategory();
        disecategory.setDicacode("L10006");
        disecategory.setDicaname("流感");
        disecategory.setSequenceno(1);
        disecategory.setDicatype(6);
        disecategory.setDelmark(1);
        disecategory.setDeldate("");

        boolean flag = disecategoryDao.addDisecategory(disecategory);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 修改
     */
    @Test
    public void updateMethod() {
        Disecategory disecategory = new Disecategory();
        disecategory.setId(6);
        disecategory.setDicacode("L6");
        disecategory.setDicaname("LG");
        disecategory.setSequenceno(2);
        disecategory.setDicatype(7);
        disecategory.setDelmark(1);

        boolean flag = disecategoryDao.updateDisecategory(disecategory);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }
    }
    /**
     * 删除
     */
    @Test
    public void deleteMethod(){
        boolean flag = disecategoryDao.deleteDisecategory(6);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void queryDisecategoryID(){
        Disecategory  disecategory = disecategoryDao.findDiesecategoryID(3);
        System.out.println(disecategory);
    }
    /**
     * 查询
     */
    @Test
    public void queryMethod(){
        List<Disecategory> disecategoryList = disecategoryDao.findAll();
        for (Disecategory disecategory : disecategoryList){
            System.out.println(disecategory);
        }

    }




}

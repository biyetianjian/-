package com.software.dao;

import com.example.dao.SettlecategoryDao;
import com.example.model.Settlecategory;
import com.example.model.User;
import org.junit.jupiter.api.Test;

import java.util.List;

public class SettlecategoryDaoTest {

    SettlecategoryDao settlecategoryDao = new SettlecategoryDao();

    @Test
    public  void  addMethod1(){
        Settlecategory settlecategory = new Settlecategory();
        settlecategory.setRegistcode("P0007");
        settlecategory.setRegistname("花呗");
        settlecategory.setSequenceno(7);
        settlecategory.setDelmark(1);


        boolean flag = settlecategoryDao.addSettlecategory(settlecategory);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public  void  updateMethod(){
        Settlecategory settlecategory = new Settlecategory();
        settlecategory.setId(1);
        settlecategory.setRegistcode("P0007");
        settlecategory.setRegistname("花呗");
        settlecategory.setSequenceno(7);
        settlecategory.setDelmark(1);


        boolean flag = settlecategoryDao.updateSettlecategory(settlecategory);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void deleteMethod(){
        boolean flag = settlecategoryDao.deleteSettlecategory(15);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void querySettlecategory(){
        List<Settlecategory> settlecategoryList = settlecategoryDao.findAll();
        for (Settlecategory settlecategory : settlecategoryList){
            System.out.println(settlecategory);
        }
    }
    @Test
    public void querySettlecategoryId(){
        Settlecategory settlecategory =settlecategoryDao.findSettlecategoryID(1);
        System.out.println(settlecategory);
    }

    @Test
    public void cancelsettlecategoryr(){
        Settlecategory settlecategory =settlecategoryDao.findSettlecategoryID(1);
        System.out.println(settlecategory);
    }
}

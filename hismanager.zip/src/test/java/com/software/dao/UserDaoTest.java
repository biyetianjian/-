package com.software.dao;

import com.example.dao.RegistlevelDao;
import com.example.dao.UserDao;
import com.example.model.Registlevel;
import com.example.model.User;
import org.junit.jupiter.api.Test;

import java.util.List;

public class UserDaoTest {
    UserDao userDao = new UserDao();


    @Test
    public  void  addMethod1(){
        User user = new User();
        user.setUsername("w101");
        user.setPassword("75964");
        user.setRealname("李华");
        user.setUsetype(3);
        user.setDoctitleid("低级");
        user.setDeptid(4);
        user.setRegistleid(4);
        user.setDelmark(1);

        boolean flag = userDao.addUser(user);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public  void  updateMethod(){
        User user = new User();
        user.setUsername("w112");
        user.setPassword("624930");
        user.setRealname("孙勇");
        user.setUsetype(3);
        user.setDoctitleid("高级");
        user.setDeptid(4);
        user.setRegistleid(2);
        user.setDelmark(1);

        boolean flag = userDao.updateUser(user);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void deleteMethod(){
        boolean flag = userDao.deleteUser(5);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    @Test
    public void queryUser(){
        List<User> userList = userDao.findAll();
        for (User user :userList ){
            System.out.println(user);
        }
    }

    @Test
    public void queryUserId(){
        User user =userDao.findUserID(1);
        System.out.println(user);
    }


    @Test
    public void canceluser(){
        User user =userDao.findUserID(1);
        System.out.println(user);
    }
}


package com.software.dao;

import com.example.dao.PrescriptionDao;
import com.example.model.Prescription;
import org.junit.jupiter.api.Test;
import java.util.List;

public class PrescriptionDaoTest {
    PrescriptionDao prescriptionDao = new PrescriptionDao();


    /**
     * 添加
     */
    @Test
    public void addMethod1(){
        Prescription prescription = new Prescription();
        prescription.setMedicalid(9);
        prescription.setRegistlid(9);
        prescription.setUserid(9);
        prescription.setPrescriptionname("头孢");
        prescription.setPrescriptiontime("2023.10.25");
        prescription.setPrescriptionstate(9);

        boolean flag = prescriptionDao.addPrescription(prescription);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 修改
     */
    @Test
    public void updatePrescription(){
        Prescription prescription = new Prescription();
        prescription.setId(7);
        prescription.setMedicalid(9);
        prescription.setRegistlid(9);
        prescription.setUserid(9);
        prescription.setPrescriptionname("toubao");
        prescription.setPrescriptiontime("8");
        prescription.setPrescriptionstate(7);

        boolean flag = prescriptionDao.updatePrescription(prescription);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    /**
     * 删除
     */
    @Test
    public void deleteMethod(){
        boolean flag = prescriptionDao.deletePrescription(7);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 查询
     */
    @Test
    public void queryMethod(){
        List<Prescription> prescriptionList = prescriptionDao.findAll();
        for (Prescription prescription : prescriptionList){
            System.out.println(prescription);
        }
    }
    @Test
    public void queryPrescriptionById(){
        Prescription prescription =prescriptionDao.findPrescriptionByID(5);
        System.out.println(prescription);
    }
}
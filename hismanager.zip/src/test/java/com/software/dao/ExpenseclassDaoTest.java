package com.software.dao;

import com.example.dao.ExpenseclassDao;
import com.example.model.Expenseclass;
import org.junit.jupiter.api.Test;

import java.util.List;

public class ExpenseclassDaoTest {


    ExpenseclassDao expenseclassDao = new ExpenseclassDao();

    //添加
    @Test
    public void addMethod1() {
        Expenseclass expenseclass = new Expenseclass();
        expenseclass.setExpcode("F10006");
        expenseclass.setExpname("吃饭费");


        boolean flag = expenseclassDao.addExpenseclass(expenseclass);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }
    }


    //修改
    @Test
    public void updateMethod() {
        Expenseclass expenseclass = new Expenseclass();
        expenseclass.setId(3);
        expenseclass.setExpcode("F10008");
        expenseclass.setExpname("护理");

        boolean flag = expenseclassDao.updateExpenseclass(expenseclass);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }
    }


    //删除
    @Test
    public void deleteMethod() {
        boolean flag = expenseclassDao.deleteExpenseclass(6);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }
    }


    //查询
    @Test
    public void queryExpenseclass() {
        List<Expenseclass> expenseclassList = expenseclassDao.findAll();
        for (Expenseclass expenseclass : expenseclassList) {
            System.out.println(expenseclass);
        }
    }

    @Test
    public void queryExpenseclassById() {
        Expenseclass expenseclass = expenseclassDao.findExpenseclassByID(3);
        System.out.println(expenseclass);
    }
}



package com.software.dao;

import com.example.dao.DiseaseDao;
import com.example.model.Disease;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DiseaseDaoTest {


    DiseaseDao diseaseDao = new DiseaseDao();

    //添加
    @Test
    public  void  addMethod1(){
        Disease disease = new Disease();
        disease.setDiseasecode("JJY");
        disease.setDiseasename("颈间炎");
        disease.setDiseaseicd("20");
        disease.setDisecategoryid(1);
        disease.setDelmark(1);



        boolean flag = diseaseDao.addDisease(disease);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    //修改
    @Test
    public  void  updateMethod(){
        Disease disease = new Disease();
        disease.setId(1);
        disease.setDiseasecode("A1001");
        disease.setDiseasename("眼科");
        disease.setDiseaseicd("1");
        disease.setDisecategoryid(1);


        boolean flag = diseaseDao.updateDisease(disease);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    //删除
    @Test
    public void deleteMethod(){
        boolean flag = diseaseDao.deleteDisease(6);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }



    //查询
    @Test
    public void queryDisease(){
        List<Disease> diseaseList = diseaseDao.findAll();
        for (Disease disease : diseaseList){
            System.out.println(disease);
        }
    }

    @Test
    public void queryDiseaseID(){
        Disease disease = diseaseDao.findDiseaseID(6);
        System.out.println(disease);
    }


}

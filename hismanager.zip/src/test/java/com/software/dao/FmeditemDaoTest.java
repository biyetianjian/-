package com.software.dao;

import com.example.dao.FmeditemDao;
import com.example.model.Fmeditem;
import org.junit.jupiter.api.Test;

import java.util.List;

public class FmeditemDaoTest {

    FmeditemDao fmeditemDao = new FmeditemDao();

    /**
     * 添加
     */
    @Test
    public void addMethod(){
        Fmeditem fmeditem = new Fmeditem();

        fmeditem.setItemcode("M00006");
        fmeditem.setItemname("血常规");
        fmeditem.setExpclassid(4);
        fmeditem.setDeptid(11);
        fmeditem.setMnemoniccode("XCG");
        fmeditem.setCreationdate("2023-7-17");
        fmeditem.setLastupdatedate("2023-7-20");
        fmeditem.setRecordtype(1);
        fmeditem.setDelmark(1);
        fmeditem.setDeldate("2023");

        boolean flag = fmeditemDao.addFmeditem(fmeditem);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }

    }

    /**
     * 修改
     */
    @Test
    public void updateMethod(){
        Fmeditem fmeditem = new Fmeditem();
        fmeditem.setId(2);
        fmeditem.setItemcode("M00007");
        fmeditem.setItemname("胃镜");
        fmeditem.setExpclassid(3);
        fmeditem.setDeptid(10);
        fmeditem.setMnemoniccode("WJ");
        fmeditem.setCreationdate("2023-7-16");
        fmeditem.setLastupdatedate("2023-7-16");
        fmeditem.setRecordtype(1);
        fmeditem.setDelmark(1);
        fmeditem.setDeldate("2023");

        boolean flag = fmeditemDao.updateFmeditem(fmeditem);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 删除
     */
    @Test
    public void deleteMethod(){
        boolean flag = fmeditemDao.deleteFmeditem(6);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 查询
     */
    @Test
    public void queryFmeditem() {
        List<Fmeditem> fmeditemList = fmeditemDao.findAll();
        for (Fmeditem fmeditem : fmeditemList) {
            System.out.println(fmeditem);
        }
    }
    @Test
    public void queryFmeditemById() {
        Fmeditem fmeditem = fmeditemDao.findFmeditemByID(3);
        System.out.println(fmeditem);
    }

}

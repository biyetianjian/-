package com.example.dao;

import com.example.dao.MedicalrecordDao;
import com.example.model.Drugs;
import com.example.model.Medicalrecord;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class MedicalrecordDaoTest {

    //创建数据库访问层对象
    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setCasenumber("11");
        medicalrecord.setRegistid(9);
        medicalrecord.setPresenttreat("神经");
        medicalrecord.setHistory("无");
        medicalrecord.setAllergy("无");
        medicalrecord.setProposal("扫描");
        medicalrecord.setCasestate(1);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = medicalrecordDao.addMedicalrecord(medicalrecord);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }
    @Test
    public  void  updateMethod(){
        //1.创建添加的科室测试用例
        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setId(5);
        medicalrecord.setCasenumber("11");
        medicalrecord.setRegistid(9);
        medicalrecord.setPresenttreat("神经");
        medicalrecord.setHistory("无");
        medicalrecord.setAllergy("无");
        medicalrecord.setProposal("扫描");
        medicalrecord.setCasestate(1);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = medicalrecordDao.updateMedicalrecord(medicalrecord);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }


    @Test
    public void queryMedicalRecord(){
        List<Medicalrecord> medicalrecordList =  medicalrecordDao.findAll();
        for(Medicalrecord medicalrecord : medicalrecordList){
            System.out.println(medicalrecord);
        }
    }


}

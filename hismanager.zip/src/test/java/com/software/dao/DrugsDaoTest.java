package com.software.dao;

import com.example.dao.DrugsDao;
import com.example.model.Drugs;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DrugsDaoTest {

    DrugsDao drugsDao = new DrugsDao();

    @Test
    public  void  addMethod1(){
        Drugs drugs = new Drugs();
        drugs.setDrugscode("C10008");
        drugs.setDrugsname("阿奇霉素");
        drugs.setDrugsformat("75mg");
        drugs.setDrugsunit("盒");
        drugs.setManufacturer("吉利德科学公司");
        drugs.setDrugsprice(79);
        drugs.setDrugstypeid(1);
        drugs.setMnemoniccode("1");
        drugs.setCreationdate("2020/9/16");

        boolean flag = drugsDao.addDrugs(drugs);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public  void  updateMethod(){
        Drugs drugs = new Drugs();
        drugs.setId(9);
        drugs.setDrugscode("C100018");
        drugs.setDrugsname("阿奇霉素");
        drugs.setDrugsformat("75mg");
        drugs.setDrugsunit("盒");
        drugs.setManufacturer("吉利德科学公司");
        drugs.setDrugsprice(79);
        drugs.setDrugstypeid(1);
        drugs.setMnemoniccode("1");
        drugs.setCreationdate("2020/9/16");


        boolean flag = drugsDao.updateDrugs(drugs);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void deleteMethod(){
        boolean flag = drugsDao.deleteDrugs(8);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void queryDrugs(){
        List<Drugs> drugsList = drugsDao.findAll();
        for (Drugs drugs :drugsList ){
            System.out.println(drugs);
        }
    }
    @Test
    public void queryDrugstById(){
        Drugs drugs =drugsDao.findDrugsByID(3);
        System.out.println(drugs);
    }

}
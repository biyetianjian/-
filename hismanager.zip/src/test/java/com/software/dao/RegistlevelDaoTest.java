package com.software.dao;

import com.example.dao.RegistlevelDao;
import com.example.model.Registlevel;
import com.example.model.User;
import org.junit.jupiter.api.Test;

import java.util.List;

public class RegistlevelDaoTest {

    RegistlevelDao registlevelDao = new RegistlevelDao();

    @Test
    public  void  addMethod1(){
        Registlevel registlevel = new Registlevel();
        registlevel.setRegistcode("A0001");
        registlevel.setRegistname("普通外科门诊");
        registlevel.setSequenceno(4);
        registlevel.setRegistfee("10");
        registlevel.setRegistquota(50);
        registlevel.setDelmark(1);
        registlevel.setDeldate("");



        boolean flag = registlevelDao.addRegistlevel(registlevel);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    @Test
    public  void  updateMethod(){
        Registlevel registlevel = new Registlevel();
        registlevel.setId(8);
        registlevel.setRegistcode("A0008");
        registlevel.setRegistname("妇产科门诊");
        registlevel.setSequenceno(8);
        registlevel.setRegistfee("50");
        registlevel.setRegistquota(5);
        registlevel.setDelmark(1);
        registlevel.setDeldate("");



        boolean flag = registlevelDao.updateRegistlevel(registlevel);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    @Test
    public void deleteMethod(){
        boolean flag = registlevelDao.deleteRegistlevel(8);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    @Test
    public void queryRegistlevel(){
        List<Registlevel> registlevelList = registlevelDao.findall();
        for (Registlevel registlevel :registlevelList ){
            System.out.println(registlevel);
        }
    }

    @Test
    public void queryRegistlevelId(){
        Registlevel registlevel =registlevelDao.findRegistlevelId(2);
        System.out.println(registlevel);
    }

    @Test
    public void cancelregistlevel(){
        Registlevel registlevel =registlevelDao.findRegistlevelId(1);
        System.out.println(registlevel);
    }

}

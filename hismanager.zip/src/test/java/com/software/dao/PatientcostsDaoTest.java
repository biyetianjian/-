package com.software.dao;

import com.example.dao.PatientcostsDao;
import com.example.model.Patientcosts;

import com.example.model.Prescriptiondetailed;
import org.junit.jupiter.api.Test;
import java.util.List;

public class PatientcostsDaoTest {
    PatientcostsDao patientcostsDao = new PatientcostsDao();


    /**
     * 添加
     */
    @Test
    public void addMethod(){
        Patientcosts patientcosts = new Patientcosts();
        patientcosts.setRegistid(6);
        patientcosts.setItemid(6);
        patientcosts.setItemtype(1);
        patientcosts.setName("WJ");
        patientcosts.setUnitprice(200);
        patientcosts.setAmount(1);
        patientcosts.setRegisterid(1);
        patientcosts.setCreateoperid(1);

        patientcosts.setFeetype(1);
        patientcosts.setRetmark(1);
        patientcosts.setRetdate("1");


        boolean flag = patientcostsDao.addPatientcosts(patientcosts);
        if (flag){
            System.out.println("succsee");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 查询
     */
    @Test
    public void queryPatientcosts(){
        List<Patientcosts> patientcostsList = patientcostsDao.findALL();
        for (Patientcosts patientcosts : patientcostsList){
            System.out.println(patientcosts);
        }
    }


    @Test
    public void queryPatientcostsById(){
        Patientcosts patientcosts =patientcostsDao.findPatientcostsByID(5);
        System.out.println(patientcosts);
    }


}


package com.software.dao;

import com.example.dao.CheckapplyDao;
import com.example.model.Checkapply;
import org.junit.jupiter.api.Test;
import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class CheckapplyDaoTest {

    //创建数据库访问层对象
    CheckapplyDao checkapplyDao = new CheckapplyDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Checkapply checkapply = new Checkapply();

        checkapply.setItemid(7);
        checkapply.setName("切除");
        checkapply.setObjective("切除手术");
        checkapply.setPosition("肾");
        checkapply.setIsurgent(0);
        checkapply.setNum(1);
        checkapply.setCreationtime("2020.5.6");
        checkapply.setCheckoperid(4);
        checkapply.setResultoperid(4);
        checkapply.setState(5);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = checkapplyDao.addCheckapply(checkapply);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }
    @Test
    public void updateCheckapply(){
        //1.创建修改科室测试用例
        Checkapply checkapply = new Checkapply();
        checkapply.setId(5);
        checkapply.setCreationtime("2020.05.06");
        checkapply.setCheckoperid(3);
        checkapply.setResultoperid(3);
        checkapply.setState(0);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = checkapplyDao.updateCheckapply(checkapply);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }
    @Test
    public void deleteMethod(){
        boolean flag = checkapplyDao.deleteCheckapply(19);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryCheckapply(){
        List<Checkapply> checkapplyList = checkapplyDao.findAll();
        for(Checkapply checkapply : checkapplyList){
            System.out.println(checkapply);
        }
    }
    @Test
    public void queryDepartById(){
        Checkapply checkapply =checkapplyDao.findCheckapplyByID(20);
        System.out.println(checkapply);
    }

}

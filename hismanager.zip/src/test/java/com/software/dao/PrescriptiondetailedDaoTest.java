package com.software.dao;

import com.example.dao.PrescriptiondetailedDao;
import com.example.model.Prescriptiondetailed;
import org.junit.jupiter.api.Test;

import java.util.List;


public class PrescriptiondetailedDaoTest {
    PrescriptiondetailedDao prescriptiondetailedDao = new PrescriptiondetailedDao();


    /**
     * 添加
     */

    @Test
    public void addMethod(){
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setPrescriptionid(6);
        prescriptiondetailed.setDrugsid(7);
        prescriptiondetailed.setDrugsusage("口服");
        prescriptiondetailed.setDosage("一次两片");
        prescriptiondetailed.setFrequency("一天两次");
        prescriptiondetailed.setAmount(2);
        prescriptiondetailed.setState(4);


        boolean flag = prescriptiondetailedDao.addPrescriptiondetailed(prescriptiondetailed);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }
    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updatePrescriptiondetailed(){
        //1.创建修改科室测试用例
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setId(8);
        prescriptiondetailed.setPrescriptionid(1);
        prescriptiondetailed.setDrugsid(1);
        prescriptiondetailed.setDrugsusage("1");
        prescriptiondetailed.setDosage("1");
        prescriptiondetailed.setFrequency("1");
        prescriptiondetailed.setAmount(1);
        prescriptiondetailed.setState(1);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = prescriptiondetailedDao.updatePrescriptiondetailed(prescriptiondetailed);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }
    /**
     * 删除
     */
    @Test
    public void deleteMethod(){
        boolean flag = prescriptiondetailedDao.deletePrescriptiondetailed(11);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }

    }
    @Test
    public void queryPrescriptiondetailed(){
        List<Prescriptiondetailed> prescriptiondetailedList =  prescriptiondetailedDao.findAll();
        for(Prescriptiondetailed prescriptiondetailed : prescriptiondetailedList){
            System.out.println(prescriptiondetailed);
        }
    }

    @Test
    public void queryPrescriptiondetailedById(){
        Prescriptiondetailed prescriptiondetailed =prescriptiondetailedDao.findPrescriptiondetailedByID(5);
        System.out.println(prescriptiondetailed);
    }


}

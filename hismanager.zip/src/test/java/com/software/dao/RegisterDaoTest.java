package com.software.dao;

import com.example.dao.RegisterDao;
import com.example.model.Department;
import com.example.model.Register;
import org.junit.jupiter.api.Test;
import java.util.List;

public class RegisterDaoTest {
    RegisterDao registerDao = new RegisterDao();


    //添加
    @Test
    public void addMethod(){
        Register register = new Register();

        register.setRealname("MQ");
        register.setGender("Male");
        register.setIdnumber("123456************");
        register.setBirthdate("20000321");
        register.setAge(23);
        register.setAgetype("1");
        register.setHomeaddress("SXXD");
        register.setDeptid(4);
        register.setUserid(3);
        register.setRegisttime("20230924 12:05");
        register.setVisitstate(4);

        boolean flag = registerDao.addRegister(register);
        if (flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }


    }

    /**
     * 修改
     */
    @Test
    public void updateMethod(){
        Register register = new Register();
        register.setId(6);
        register.setVisitstate(0);

        boolean flag = registerDao.updateRegister(register);
        if (flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }


    //删除
    @Test
    public void deleteMethod(){
        boolean flag = registerDao.deleteRegister(11);
        if(flag){
            System.out.println("success");
        }else {
            System.out.println("failure");
        }
    }

    /**
     * 查询
     */

    @Test
    public void queryRegisterID(){
        Register register = registerDao.findRegisterID(3);
        System.out.println(register);
    }


    @Test
    public void queryMethod(){
        List<Register> registerList = registerDao.findALL();
        for (Register register : registerList){
            System.out.println(register);
        }
    }

}
